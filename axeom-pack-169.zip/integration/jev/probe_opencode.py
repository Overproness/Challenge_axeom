"""One explicitly free Jev request; read a secret from hidden stdin, never a file/argv."""
import json
import argparse
import re
import subprocess
import sys
import termios
import time
from datetime import datetime, timezone
from pathlib import Path
import urllib.error
import urllib.request

ENDPOINT='https://opencode.ai/inference/systemone/v1/systemone'
MODEL='jev-1.13-free'
OUT=Path(__file__).resolve().parent/'opencode_probe.json'

class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,*args,**kwargs):
        raise RuntimeError('Redirect refused; credentials are restricted to the documented OpenCode endpoint.')

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--transport',choices=['urllib','curl'],default='urllib');args=parser.parse_args()
    previous=None
    if sys.stdin.isatty():
        previous=termios.tcgetattr(sys.stdin)
        hidden=termios.tcgetattr(sys.stdin);hidden[3]&=~termios.ECHO
        termios.tcsetattr(sys.stdin,termios.TCSANOW,hidden)
    print('Ready for OpenCode secret JSON on stdin (input is hidden).',flush=True)
    key=''
    try:
        value=json.loads(sys.stdin.readline());key=value.pop('api_key','')
        if not key:raise RuntimeError('No API key provided; no request sent.')
        payload={'model':MODEL,'state':'Please make the captions bigger on the video.','questions':{'needs_revision':{'type':'noul','instructions':'Does the message request a change to an existing video?'}}}
        request=urllib.request.Request(ENDPOINT,data=json.dumps(payload).encode(),headers={'Content-Type':'application/json','Authorization':'Bearer '+key},method='POST')
        report={'provider':'OpenCode','requested_model':MODEL,'endpoint':ENDPOINT,'transport':args.transport,'started_at':datetime.now(timezone.utc).isoformat(),'request':payload,'paid_fallback':False}
        started=time.monotonic()
        try:
            if args.transport=='curl':
                def cq(s):return '"'+s.replace('\\','\\\\').replace('"','\\"').replace('\n','\\n').replace('\r','\\r')+'"'
                config='\n'.join(['header = '+cq('Content-Type: application/json'),'header = '+cq('Authorization: Bearer '+key),'data = '+cq(json.dumps(payload))])+'\n'
                result=subprocess.run(['curl','--silent','--show-error','--max-time','30','--request','POST','--url',ENDPOINT,'--config','-','--write-out','\n%{http_code}'],input=config,capture_output=True,text=True,timeout=35)
                body,_,code=result.stdout.rpartition('\n');code=int(code) if code.isdigit() else 0
                if result.returncode:raise RuntimeError('curl connection failed: '+result.stderr.replace(key,'[REDACTED]'))
                if code==200:report.update(http_status=code,response=json.loads(body),status='succeeded')
                else:report.update(http_status=code,status='failed',error_body=re.sub(r'oc_sk_[A-Za-z0-9_-]+','[REDACTED]',body.replace(key,'[REDACTED]'))[:4096])
            else:
                with urllib.request.build_opener(NoRedirect()).open(request,timeout=30) as response:
                    report.update(http_status=response.status,response=json.load(response),status='succeeded')
        except urllib.error.HTTPError as error:
            body=error.read(4096).decode('utf-8',errors='replace').replace(key,'[REDACTED]')
            body=re.sub(r'oc_sk_[A-Za-z0-9_-]+','[REDACTED]',body)
            report.update(http_status=error.code,status='failed',error_body=body)
        except (urllib.error.URLError,TimeoutError,RuntimeError) as error:
            report.update(status='connection_failed',error=str(error).replace(key,'[REDACTED]'))
        report['latency_ms']=round((time.monotonic()-started)*1000)
        encoded=json.dumps(report,ensure_ascii=False,indent=2).replace(key,'[REDACTED]')
        OUT.write_text(encoded+'\n')
        print(encoded,flush=True)
    finally:
        key=''
        if previous:termios.tcsetattr(sys.stdin,termios.TCSANOW,previous)

if __name__=='__main__':main()
