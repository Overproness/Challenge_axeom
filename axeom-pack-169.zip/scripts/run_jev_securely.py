#!/usr/bin/env python3
"""Prompt privately for the selected Jev provider's key and evaluate real results.

Never purchases credits, creates accounts, changes provider on failure, writes
keys to files, or puts keys in shell arguments/history.
"""
import argparse
import getpass
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
CLIENT = ROOT / 'integration/jev/jev_triage.py'
sys.path.insert(0, str(CLIENT.parent))
from jev_triage import PROVIDERS, provider_settings

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--provider', choices=PROVIDERS, default='typesafe')
    parser.add_argument('--limit', type=int, help='Use 1 for a single-message probe; default evaluates all 40 reference cases')
    parser.add_argument('--all', action='store_true', help='Process all inbound messages instead of only the 40 reference cases')
    parser.add_argument('--transport', choices=('urllib','curl'), help='Default is curl for OpenCode, urllib for TypeSafe')
    parser.add_argument('--predictions', type=Path, default=CLIENT.parent / 'jev_results.json')
    parser.add_argument('--evaluation', type=Path, default=CLIENT.parent / 'evaluation.json')
    args = parser.parse_args()
    if args.limit is not None and args.limit < 1:
        parser.error('--limit must be a positive integer')
    settings = provider_settings(args.provider, transport=args.transport)
    print(f"Selected provider: {args.provider}; model: {settings['model']}.")
    size = 'all inbound' if args.all else '40 reference'
    print(f"This processes {size} messages{f', capped at {args.limit}' if args.limit else ''}, using {settings['transport']}. Nothing is sent to studio clients.")
    if args.provider == 'opencode':
        print('Uses only the documented limited-time jev-1.13-free model. If access fails, it stops; it never switches to a paid model or another provider.')
    else:
        print('TypeSafe direct calls consume organization credits; there are no free/trial credits. Use authorized supplied access or resolve the free-tools rule first.')
    print('The applicant reports completing reference-label review. This selected development sample does not establish production performance.')
    key = os.environ.get(settings['api_key_env'])
    if not key:
        if not sys.stdin.isatty():
            raise SystemExit('Run this command in your interactive terminal so the key can be entered with echo disabled.')
        key = getpass.getpass(f'Paste {args.provider} API key (hidden): ').strip()
    if not key:
        raise SystemExit('No key entered. Nothing was sent.')
    env = os.environ.copy()
    env[settings['api_key_env']] = key
    try:
        command = [sys.executable, str(CLIENT), 'run', '--provider', args.provider, '--transport', settings['transport'], '--predictions', str(args.predictions)]
        if args.all:
            command.append('--all')
        if args.limit is not None:
            command.extend(['--limit', str(args.limit)])
        result = subprocess.run(command, cwd=ROOT, env=env)
        if result.returncode:
            raise SystemExit('Jev did not complete. Inspect the error and saved partial results; no complete accuracy evaluation is claimed.')
        subprocess.run([sys.executable, str(CLIENT), 'evaluate', '--predictions', str(args.predictions), '--output', str(args.evaluation)], cwd=ROOT, check=True)
        print(f'Saved {args.predictions} and {args.evaluation}.')
        print('Run complete. Review the saved results; the key itself does not need to be shared.')
    finally:
        env.pop(settings['api_key_env'], None)
        key = None

if __name__ == '__main__':
    main()
