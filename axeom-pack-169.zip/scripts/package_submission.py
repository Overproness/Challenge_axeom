#!/usr/bin/env python3
"""Build the handoff ZIP without credentials, caches, Git internals or recursive ZIPs."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import hashlib
import json

ROOT=Path(__file__).resolve().parents[1]
OUTPUT=ROOT/'submission'/'axeom-pack-169.zip'
FILES=['README.md','answers.json','writeup.md','writeup.pdf','assumptions.md','daily_log.md','ai_log.md',
       'recording_guide.md','video_transcript.md','requirements_checklist.md','hosting_receipt.json']
FOLDERS=['data','analysis','integration','verification','demo','scripts','axeom-desk']

def included(path):
    rel=path.relative_to(ROOT)
    return not any(p in {'.git','node_modules','__pycache__','.sites','runtime','private'} for p in rel.parts) and path.suffix not in {'.zip','.tar','.gz','.pyc','.log'} and not path.name.startswith('.env') and path.name not in {'package-manifest.json'}

def main():
    OUTPUT.parent.mkdir(exist_ok=True)
    paths=[ROOT/f for f in FILES if (ROOT/f).is_file()]
    for folder in FOLDERS:
        paths.extend(p for p in (ROOT/folder).rglob('*') if p.is_file() and included(p))
    paths=sorted(set(paths))
    manifest=[]
    with ZipFile(OUTPUT,'w',ZIP_DEFLATED) as z:
        for p in paths:
            rel=str(p.relative_to(ROOT));data=p.read_bytes();z.writestr(rel,data)
            manifest.append({'path':rel,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
        z.writestr('package-manifest.json',json.dumps({'pack_id':169,'files':manifest},indent=2))
    with ZipFile(OUTPUT) as z:
        assert z.testzip() is None
    print(json.dumps({'zip':str(OUTPUT),'files':len(paths)+1,'bytes':OUTPUT.stat().st_size,'sha256':hashlib.sha256(OUTPUT.read_bytes()).hexdigest()}))

if __name__=='__main__':main()
