# Video transcript — awaiting the applicant’s recording

No video has been recorded. This file deliberately contains no invented transcript.

Follow `recording_guide.md`, then replace this file with a transcript of the actual 5–10 minute recording. Include the real video URL and any timestamps provided by the recording tool. The personal camera-on answers must be spoken without notes or cuts.
