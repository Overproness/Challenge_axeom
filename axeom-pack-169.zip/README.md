# Axeom Challenge — Pack 169

Open `answers.json` for the live app URL and all findings. `submission/axeom-pack-169.zip` is the handoff archive. Name/email remain placeholders; recording remains an applicant follow-up item. Real free Jev inference and its measured benchmark are complete.

## What was built

A static, mobile owner desk that connects 30 clients to bookings, invoices, payments, production, messages and leads. All calculations run from raw data in the browser. Source files are preserved. Uploads are validated before an approval step, merged by primary key, and recomputed. Suggestions produce local tasks/board notes only.

The initial findings are $11,050 confirmed overdue, $900 unapplied Keystone credit, $2,040 completed work without billing, six incorrect billing status flags and 44 strict instruction-capture gaps. The $1,500 canceled booking is held separately. Read the evidence and assumptions for what those numbers establish.

## Deliverable map

| File | Purpose |
|---|---|
| `answers.json` | Completed template plus explicit audit context |
| `writeup.md` / `writeup.pdf` | Two-page explanation of proof, implementation, cost, limits and next two weeks |
| `assumptions.md` | Questions that could not be asked and the assumptions used |
| `daily_log.md` | Actual work log; no fabricated second/third day |
| `recording_guide.md` | Timed 7–8 minute demo and personal recording instructions |
| `video_transcript.md` | Clearly marked pending until an actual recording exists |
| `analysis/finance/` | Independent financial analysis, balances and match proof |
| `analysis/requests/` | Request-by-request source audit and lead/churn proof |
| `integration/jev/` | Real Jev client, raw responses, reference labels, evaluation and historical access failures |
| `axeom-desk/dist/` | Complete app source; no build or dependencies required |
| `verification/` | Automated tests, mobile browser results and screenshots |
| `demo/new-files/` | Six small unseen-file fixtures for recording the upload demonstration |

## Run and verify

From the pack root:

```sh
python3 -m http.server 8765 --bind 127.0.0.1 --directory axeom-desk/dist
```

Open `http://127.0.0.1:8765`. Opening the HTML directly with `file://` will not load module/data fetches.

## Host it yourself

The complete website is the `axeom-desk/dist/` folder. Its HTML, CSS, JavaScript modules and JSON files are the source; there is no separate build step. Upload the entire folder's contents to any static HTTP(S) host, with `index.html` at the site's root. Keep the `evidence/` and `jev/` subfolders and relative paths intact. No Node package installation, backend or API key is required to serve the app and its recorded Jev suggestions.

For a drag-and-drop host, select the `dist` folder. For a Git-connected host using this full repository, leave the build command empty and set the publish directory to `axeom-desk/dist`. Make the resulting challenge URL publicly accessible without login and test it in a private browser window. Update `live_link` and `code_or_files_link` in `answers.json` and its copy at `axeom-desk/dist/evidence/answers.json` if you change the app or download URL.

The handoff ZIP excludes nested ZIPs. When hosting from an extracted handoff, copy `submission/axeom-pack-169.zip` into `axeom-desk/dist/axeom-pack-169.zip` to retain the app's submission-download link. Browser changes and uploads stay in that browser's local storage; they are not shared across devices or written back to the hosted source files. Jev API calls are a separate local Python workflow documented in `integration/jev/SETUP.md`.

```sh
python3 analysis/finance/analyze.py
python3 analysis/requests/analyze.py
node --test --test-isolation=none verification/integration.test.mjs verification/request-engine.test.mjs
node analysis/finance/test-engine.mjs
python3 -m unittest discover -s integration/jev -p 'test_*.py'
python3 scripts/package_submission.py
```

Browser QA uses installed Chromium plus Python websocket-client. It creates a temporary browser profile and tests a local HTTP server; see `verification/browser_qa.py`. Re-run only after a relevant change. The reports distinguish local mobile emulation from published anonymous access: 35 initial local and 40 initial published checks passed; the updated Jev version passed 58 additional browser checks. A fresh profile needed no login. `verification/make_writeup_pdf.py` creates the verified two-page PDF without a browser.

## Jev and personal follow-up

The direct TypeSafe API requires funded access. OpenCode's documented `jev-1.13-free` succeeded on the supplied zero-balance account and reported free billing and $0 cost. All 192 inbound messages were classified at reported cost $0. The frozen 40-case benchmark matched 37 routing, 36 edit-request and 40 continuation-risk labels. This selected development sample includes only 3 risk-positive cases, so its scores do not guarantee future performance. A second blinded review flagged one ambiguous label. See `integration/jev/evaluation.json`, actual raw results and the five disagreements. Run `python3 scripts/run_jev_securely.py --provider opencode` to reproduce with your own key. No key is shipped in the source, website or ZIP. Imported Jev results are source-matched and review-only.

Replace personal placeholders, record the guide, supply a real video link and transcript, and regenerate the ZIP. Nothing has been submitted to the challenge organizers. A published public app does not prove the candidate has completed the camera-on interview or met the unknown receipt-based deadline.

The Sites project ID and deployment manifest are retained in `axeom-desk/.openai/hosting.json`. Source is packaged through the Sites workflow. `hosting_receipt.json` records the verified live version when available. No credentials are included.
