# Recording guide — aim for 7–8 minutes

This is a guide, **not a recording or transcript**. You must appear on camera and speak personally. Explain the decisions you understand and stand behind, using the reviewed work and challenge PDFs for preparation.

## Before recording

1. Replace `YOUR NAME HERE` and `YOUR EMAIL HERE` in `answers.json`. Keep the original data date October 6, 2026.
2. Open the live link from `answers.json` in a private/incognito browser. Show a narrow window or a phone-sized viewport. Reset the app under Files & evidence if you have test data in your browser.
3. Download the submission files. Use the six small demonstration fixtures in `verification/browser/fixtures/`: `qa-leads.csv`, `qa-bookings.csv`, `qa-invoices.csv`, `qa-payments.csv`, `qa-board.csv`, and `qa-messages.txt`. The script may leave the payment fixture in its corrected state; **use the ready-to-show baseline files in `demo/new-files/`** for the exact numbers below.
4. Set your recording tool to screen + microphone + webcam. Check public sharing with no login. No paid software is required; any available free recorder is suitable.
5. The demonstration may follow this guide. For the three personal questions at the end, put the guide away, keep the camera on, and answer in one continuous uncut take. Do not read prepared answers.

## Timed walkthrough

| Time | Show | Explain in your own words |
|---|---|---|
| 0:00–0:35 | Today screen | The data date is October 6. The first action is Price's contract concern; cash and request handoffs follow. These priorities connect to evidence, not arbitrary scores. |
| 0:35–1:20 | Money → Wrong flags; click an invoice | Show an invoice's actual bank allocations. Explain explicit references are reserved first. Demonstrate the $900 Lena bundle or Sterling's unsupported paid flag. Point out the $1,500 canceled-service dispute is excluded from confirmed collection. |
| 1:20–1:55 | Clients → Price; optionally Northstar | Show client messages, invoices, bookings and videos. Northstar is the payer for two separate recipients. Similar names do not justify merging clients. |
| 1:55–2:45 | Add new files → select all six `demo/new-files/` files | Show the import preview; approve. There should now be 31 clients, $12,050 overdue, 45 missing instructions and 24 waiting items. Re-upload the same six files: zero additions/changes and unchanged totals. |
| 2:45–3:25 | Requests → search `QA` → Review handoff | Confirm V999, instruction, Ali and due date. Approve. The original message stays attached and the missing count falls to 44. Return Today to show the assigned follow-up and mark it complete. Nothing was sent. |
| 3:25–4:00 | Requests → Jev triage; Files & evidence → Jev section | Show the real source-linked Jev suggestions and evaluator: 37/40 routing, 36/40 edits, 40/40 continuation risk; all reported cost $0 via the OpenCode free model. Explain that the selected 40-case development sample contains only 3 risk-positive examples and does not guarantee future performance. Discuss the five errors, owner approval and fresh-file coverage limits. |
| 4:00–4:25 | Opportunities and evidence | Show modeled contribution, state Meta leads under the declared model, and explain missing acquisition cost prevents ROI claims. Explain browser-only storage and lack of direct sending. |
| 4:25–7:30 | Stop screen navigation; keep camera on | Put away all notes. Answer the three required questions below without cuts. |

## The three required questions

- What was the hardest part, and how did you solve it?
- What did you get wrong at first?
- What would you tell the owner to stop doing?

For preparation only, review the evidence around bank references, payer/recipient identities, repeated video titles and postapproval scope changes. Actual recorded mistakes include the Northstar email-learning bug, the failed remove-prices/exact-ID/novel-edit tests, and early client-count correction. Choose examples whose reasoning you can explain accurately.

## After recording

1. Save the real video, enable no-login viewing, and test its link in an incognito window.
2. Put the actual URL in `answers.json` under `video_link`.
3. Export a real transcript from the recording tool or transcribe the actual recording. Replace `video_transcript.md` with the words you said. Correct transcription errors without disguising substantive changes or cuts.
4. Update the daily log with your actual time, review, corrections and recording. Do not invent earlier days.
5. Run `python3 scripts/package_submission.py` to regenerate the local ZIP. The live site's hosted download is a snapshot; updating local files does not automatically republish it.
6. Send the single ZIP/shared folder and both live/video links before your actual deadline. No organizer message has been sent.
