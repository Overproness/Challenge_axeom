"""Rebuild the request audit from the preserved, manually reviewed labels.

Run from the pack root: python3 analysis/requests/analyze.py
Input message line numbers are one-based, excluding no header (messages.txt has none).
The label file is a source audit artifact, not an independent model-accuracy measurement.
"""
import csv
import json
import re
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'analysis/requests'
TODAY = '2026-10-06'


def read_csv(name):
    with (ROOT / 'data' / name).open() as f:
        return list(csv.DictReader(f))


def norm(value):
    return re.sub(r'[^a-z0-9]', '', value.lower())


def main():
    board = {r['video_id']: r for r in read_csv('production_board.csv')}
    messages = (ROOT / 'data/messages.txt').read_text().splitlines()
    labels = json.loads((OUT / 'request_labels.json').read_text())
    identities_path = ROOT / 'analysis/finance/result.json'
    identities = json.loads(identities_path.read_text())['identities']['name'] if identities_path.exists() else {}
    by_month = defaultdict(Counter)
    by_editor = defaultdict(Counter)
    by_channel = defaultdict(Counter)
    lost = []
    for row in labels:
        # Fail loudly when a source row changes rather than silently reusing an old label.
        b = board[row['video_id']]
        assert messages[row['message_line'] - 1] == row['message']
        assert b['title'] == row['title'] and b['notes_on_board'] == row['notes_on_board']
        assert row['request_date'] <= TODAY
        if row['capture_status'] == 'captured':
            assert b['notes_on_board'] == row['requested_change'], row
        else:
            assert b['notes_on_board'] == '', row
        row['canonical_client'] = identities.get(norm(b['client']), b['client'])
        by_month[row['request_date'][:7]][row['capture_status']] += 1
        by_editor[b['editor']][row['capture_status']] += 1
        channel = row['came_by'].replace('instagram dm', 'instagram')
        by_channel[channel][row['capture_status']] += 1
        if row['capture_status'] == 'missing':
            lost.append({
                'video_id': row['video_id'],
                'request_date': row['request_date'],
                'came_by': channel,
                'why_it_was_lost': f"messages.txt line {row['message_line']} requests {row['requested_change'].lower()}; {row['video_id']} ({row['canonical_client']}, {b['title']}, assigned {b['editor']}) has empty notes_on_board. This proves a capture gap, not which person caused it.",
            })
    leads = read_csv('leads.csv')
    junk = {'L028', 'L031', 'L044', 'L095'}
    raw_blank = [r['lead_id'] for r in leads if not r['first_reply']]
    genuine = [r['lead_id'] for r in leads if r['lead_id'] not in junk and (not r['first_reply'] or r['first_reply'] > TODAY)]
    followups = {
        28: 'V035', 30: 'V034', 57: 'V101', 59: 'V089', 77: 'V115',
        80: 'V124', 91: 'V134', 92: 'V142', 97: 'V132', 129: 'V204',
        133: 'V196', 137: 'V194', 138: 'V224', 140: 'V184', 148: 'V211',
        149: 'V212', 152: 'V225', 153: 'V208', 154: 'V217', 158: 'V242',
        160: 'V238', 164: 'V239', 165: 'V244', 176: 'V275', 190: 'V269',
    }
    ambiguous = [
        {'message_line': 44, 'request_date': '2026-06-23', 'came_by': 'email', 'candidate_video': 'V101', 'requested_change': 'Calmer music', 'why_uncertain': 'No title in original request; July 3 patient-story follow-up supports V101, but cannot prove original video.'},
        {'message_line': 64, 'request_date': '2026-07-17', 'came_by': 'email', 'candidate_video': 'V124', 'requested_change': 'Add walk-ins welcome', 'why_uncertain': 'No title in original; July 27 wills-in-60-seconds follow-up supports V124, but cannot prove original video.'},
        {'message_line': 119, 'request_date': '2026-08-23', 'came_by': 'whatsapp', 'candidate_video': 'V224', 'requested_change': 'Phone number end card', 'why_uncertain': 'No title in original; September 1 open-house-promo follow-up supports V224, but cannot prove original video.'},
    ]
    for row in ambiguous:
        row['message'] = messages[row['message_line'] - 1]
        assert board[row['candidate_video']]['notes_on_board'] == ''
    result = {
        'as_of': TODAY,
        'lost_requests': lost,
        'lost_requests_root_causes': [
            'There is no complete transfer of instructions from messages to production_board.csv. In 118 manually mapped edit requests, 44 have empty board notes; two voice-note requests and both Instagram edit requests were missed.',
            'The handoff worsens after Zara joins on June 2: all 39 audited, named-title requests for Zara videos are missing board notes, versus 5 of 79 for other editors. This points to an onboarding/handoff/QA gap; it does not establish personal blame.',
            'Requests span email, WhatsApp, voice notes and Instagram, and senders share first names. Resolve identity by full email/phone, client aliases and shoot context; never by first name alone.',
            'Messages saying the one we shot last week omit a video ID/title; three missing requests cannot be assigned to an exact video without an assumption.',
            'Repeat titles across shoots require batch context and version history. Approval is not final forever: Sterling V018 and Evergreen V119 were approved then reopened with new scope. Do not count all revisions as studio mistakes.',
            'Price Insurance Group\'s September 3 client-wide naming instruction has no durable brand-rule field and was violated again September 10. Spanish requests also need capture: October 2 calmer-song request for Sterling V316 has no board note.',
        ],
        'lost_requests_started_getting_worse_in': '2026-06',
        'never_replied_leads': genuine,
        'raw_blank_first_reply_leads': raw_blank,
        'excluded_junk_leads': sorted(junk),
        'existing_client_leads': {
            'L077': 'Evergreen rebrand/email change; identity maintenance rather than a new customer.',
            'L090': 'Bold & Brave Podcast: unanswered short-clips upsell via personal email.',
            'L097': 'Price Insurance Group: contract/churn concern misfiled as a new lead.',
        },
        'future_reply_anomaly': {'lead': 'L098', 'first_reply': '2026-10-08', 'decision': 'Treat as unacknowledged as of October 6; do not rely on future reply or Lost status as historical truth.'},
        'most_likely_to_leave': {
            'client': 'Price Insurance Group',
            'evidence': [
                '2026-09-03 voice note from Victor at 972-555-0101 says to use the full company name for compliance; no corresponding brand instruction is on the board (messages.txt:144).',
                '2026-09-10 Victor says videos still say Price Insurance, repeats his instruction and says Not happy (messages.txt:157).',
                '2026-09-29 Sofia Price asks whether they continue via website form; L097 has no first reply (messages.txt:188; leads.csv:L097).',
                '2026-10-02 Sofia follows up asking to discuss the contract this week (messages.txt:191).',
                'The next retainer shoot is October 9 (bookings.csv:B155). Summit PT already announced a pause on June 19, so its historical churn is a warning precedent rather than the strongest current save opportunity.',
            ],
            'what_to_do_this_week': 'Zaid should acknowledge Sofia and arrange the contract conversation within one business day, before the October 9 shoot. Confirm the full legal name once as a client brand rule, have an accountable editor audit all current Price videos against it, show the corrected versions to Victor for approval, and agree named ownership plus a turnaround time for every future request. Ask what must change to continue; record the commitment and follow up this week. All outbound contact requires owner approval.',
        },
        'monday_top_3': [
            'Save Price Insurance Group: acknowledge Sofia\'s contract concern and correct the repeatedly missed full-name instruction before the October 9 retainer shoot. It is an explicit, unanswered renewal risk rather than an inferred sentiment score.',
            'Review the reconciled cash queue: collect verified overdue balances, correct paid/cancelled/duplicate billing records, decide refunds or credits, and bill completed unbilled work. Verify bank allocations before approving any reminder.',
            'Stop the next missed handoff: triage all message channels into one client/video request queue, assign an owner and due date, confirm ambiguous titles, and add a second check on Zara\'s current work. Reply to warm opportunities from Willow (July 30), Metroplex (August 19), Lena (September 3), and the Morales Tire & Auto referral (September 13).',
        ],
        'metrics': {
            'mapped_initial_edit_requests': len(labels), 'missing_board_instructions': len(lost),
            'request_month': dict(by_month), 'editor': dict(by_editor), 'channel': dict(by_channel),
            'definition': 'Counts audit capture of requested instructions on the board. They are not a causal experiment, final-delivery defect rate or Jev accuracy measurement.',
        },
        'ambiguous_original_requests': ambiguous,
        'complaint_only_videos': [
            {'video_id': 'V101', 'complaint_date': '2026-07-03', 'message_line': 57, 'why': 'Patient story is still wrong; original named request is absent.'},
            {'video_id': 'V124', 'complaint_date': '2026-07-27', 'message_line': 80, 'why': 'Wills in 60 seconds is still wrong; original named request is absent.'},
            {'video_id': 'V224', 'complaint_date': '2026-09-01', 'message_line': 138, 'why': 'Open house promo is still wrong; original named request is absent.'},
        ],
        'repeat_complaints': [{'message_line': n, 'video_id': v, 'message': messages[n-1]} for n, v in followups.items()],
        'post_approval_scope_changes': [
            {'video_id': 'V018', 'approved': '2026-05-09', 'changed': '2026-05-14', 'message_lines': [11, 15], 'note': 'Different song and new intro requested after approval. In revision; board retains only original outside-shot note. Scope-change capture gap, not proof initial delivery ignored client.'},
            {'video_id': 'V119', 'approved': '2026-07-18', 'changed': '2026-07-22', 'message_lines': [65, 70], 'note': 'Different song and new intro after approval. Board calmer-music note partially captures a later unnamed request; new intro/version change lacks durable history.'},
        ],
        'client_wide_missing_rule': {'client': 'Price Insurance Group', 'message_line': 144, 'request_date': '2026-09-03', 'came_by': 'voice note', 'instruction': 'Always say Price Insurance Group in full.', 'repeated_complaint_line': 157, 'note': 'Client-wide instruction: no precise video ID asserted.'},
    }
    (OUT / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result['metrics'], indent=2))
    print('Genuine unacknowledged as-of leads:', ', '.join(genuine))


if __name__ == '__main__':
    main()
