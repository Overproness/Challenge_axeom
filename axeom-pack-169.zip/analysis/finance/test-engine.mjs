import fs from 'node:fs';
import assert from 'node:assert/strict';
import {reconcile} from './engine-finance.mjs';
const base=JSON.parse(fs.readFileSync(new URL('./raw-fixture.json',import.meta.url)));
const expected=JSON.parse(fs.readFileSync(new URL('./result.json',import.meta.url)));
const {identities}=expected,norm=s=>s.toLowerCase().replace(/[^a-z0-9]/g,'');
const resolve=(name,email)=>identities.name[norm(name)]||identities.email[email.toLowerCase()]||name||email;
let x=reconcile(base,resolve);
assert.equal(x.overdue_total,11050);assert.equal(x.never_billed_total,2040);assert.equal(x.credits.reduce((s,r)=>s+r.amount,0),900);assert.equal(x.disputed[0].amount,1500);assert.equal(x.wrong.length,6);
assert.deepEqual(x.overdue,expected.overdue);assert.deepEqual(x.never_billed,expected.never_billed);
// New cash reduces debt; tool flags do not overwrite bank truth.
let changed=structuredClone(base);
changed.payments.push({payment_id:'P9999',date:'06/10/2026',payer:'Victor Price',payer_email:'victor@priceinsures.com',amount:'1,000.00',method:'ACH',reference:'INV-1112'});
x=reconcile(changed,resolve);assert.equal(x.overdue_total,10050);assert.equal(x.invoices.find(i=>i.invoice_no==='INV-1112').balance,1500);
// New unseen completed work becomes unbilled without changing existing results.
changed=structuredClone(base);changed.bookings.push({booking_id:'B999',date:'10/06/2026',client_name:'Sage Roofing',email:'alan@sageroofingco.com',service:'Reels Pack',status:'completed',price:'$900'});
x=reconcile(changed,resolve);assert.equal(x.never_billed_total,2940);assert(x.never_billed.some(b=>b.booking_id_or_month==='B999'));
// Malformed uploaded values are surfaced for review and do not crash.
changed=structuredClone(base);changed.payments.push({payment_id:'P9998',date:'not a date',payer:'Someone new',payer_email:'new@example.com',amount:'unknown',reference:''});
x=reconcile(changed,resolve);assert.equal(x.overdue_total,11050);assert(x.issues.some(i=>i.record==='P9998'&&i.type==='invalid_payment'));
console.log('PASS: baseline parity, unseen partial payment, unseen booking, malformed input.');
// Every bank cent is either allocated or remains attached to its original receipt.
x=reconcile(base,resolve);
const nonvoid=x.invoices.filter(i=>i.status!=='void');
assert.equal(nonvoid.reduce((s,i)=>s+i.amount_cents,0),15281000);
assert.equal(x.payments.reduce((s,p)=>s+p.amount_cents,0),12649000);
assert.equal(nonvoid.reduce((s,i)=>s+i.balance_cents,0),2722000);
assert.equal(x.payments.reduce((s,p)=>s+p.amount_cents-p.remaining_cents,0),nonvoid.reduce((s,i)=>s+i.amount_cents-i.balance_cents,0));
// An unknown explicit reference must not pay another invoice or create a refund.
changed=structuredClone(base);changed.payments.push({payment_id:'P9901',date:'06/10/2026',payer:'Victor Price',payer_email:'victor@priceinsures.com',amount:'1000',method:'ACH',reference:'INV-9999'});
x=reconcile(changed,resolve);assert.equal(x.overdue_total,11050);assert.equal(x.credits.reduce((s,p)=>s+p.amount,0),900);assert.equal(x.quarantined.find(p=>p.payment==='P9901').amount,1000);
// Future invoices and receipts never change the as-of debt or allocations.
changed=structuredClone(base);changed.invoices.push({invoice_no:'INV-9902',bill_to:'Victor Price',email:'victor@priceinsures.com',issued:'2026-10-07',due:'2026-10-01',amount:'1000',status:'unpaid',memo:''});changed.payments.push({payment_id:'P9902',date:'07/10/2026',payer:'Victor Price',payer_email:'victor@priceinsures.com',amount:'1000',method:'ACH',reference:'INV-1112'});
x=reconcile(changed,resolve);assert.equal(x.overdue_total,11050);assert.equal(x.invoices.find(i=>i.invoice_no==='INV-9902').future,true);assert.equal(x.payments.find(p=>p.payment_id==='P9902').allocations.length,0);
// A far-away unreferenced old service is not silently consumed by a new bill.
changed=structuredClone(base);changed.bookings.push({booking_id:'B9903',date:'01/01/2026',client_name:'Sage Roofing',email:'alan@sageroofingco.com',service:'Reels Pack',status:'completed',price:'123'});changed.invoices.push({invoice_no:'INV-9903',bill_to:'Alan Ortiz',email:'alan@sageroofingco.com',issued:'2026-10-01',due:'2026-10-15',amount:'123',status:'unpaid',memo:''});
x=reconcile(changed,resolve);assert(x.never_billed.some(b=>b.booking_id_or_month==='B9903'));assert.equal(x.bridge['INV-9903'],undefined);assert(x.issues.some(i=>i.record==='INV-9903'));
// Shared dates/prices alone never establish a new third-party payer identity.
changed=structuredClone(base);changed.invoices.push({invoice_no:'INV-9904',bill_to:'Unrelated Agency',email:'unrelated@example.com',issued:'2026-06-12',due:'2026-06-26',amount:'900',status:'unpaid',memo:'Reels Pack 6/12'});
x=reconcile(changed,resolve);assert.equal(x.payer_recipients['Unrelated Agency'],undefined);assert.equal(x.bridge['INV-9904'],undefined);
console.log('PASS: monetary conservation, unknown-reference quarantine, future as-of exclusion, distant-service review, unrelated-payer rejection.');
