"""Reproduce Pack 169 reconciliation. Dollars are Decimal internally; data-as-of 2026-10-06."""
import csv,json,re,collections
from pathlib import Path
from datetime import date,datetime
from decimal import Decimal, ROUND_HALF_UP
ROOT=Path(__file__).resolve().parents[2]
OUT=Path(__file__).resolve().parent
TODAY=date(2026,10,6)
def read(n):return list(csv.DictReader((ROOT/'data'/f'{n}.csv').open()))
def money(s):return Decimal(s.replace('$','').replace(',',''))
def norm(s):return re.sub(r'[^a-z0-9]','',s.lower())
bookings,invoices,payments,leads,board,team=[read(n) for n in ['bookings','invoices','payments','leads','production_board','team']]
CANON=[
('Bloom Church','media@bloomdfw.org'),('Bold & Brave Podcast','lena@boldandbrave.fm'),('Tran Dental','office@trandental.com'),('Metroplex Makers Podcast','raj@metroplexmakers.fm'),('Silverleaf Builders','david@silverleaf.build'),('Sage Roofing Co','alan@sageroofingco.com'),('Maple Med Spa','aisha@maplemedspa.com'),('Sterling Bridal Boutique','simone@sterlingbridal.com'),('Horizon Wealth Partners','rtran@horizonwp.com'),('Morales Law','amorales@moraleslaw.com'),('Mesquite Fit','angela@mesquitefit.co'),('Summit Physical Therapy','vlopez@summitptdallas.com'),('Vista Med Spa','carmen@vistamedspa.com'),('Keystone Barbershop','mateo@keystonebarbers.com'),('Price Insurance Group','victor@priceinsures.com'),('Oak Cliff Realty LLC','joy@oakcliffrealty.com'),('Patel Dental','hello@pateldental.com'),('Sunset Pediatrics','trivera@sunsetpeds.com'),('Tran Family Law','info@tranfamilylaw.com'),('Cedar Coffee Roasters','sofia@cedarcoffee.com'),('Bayou Builders','jordan@bayou.build'),('Meridian Physical Therapy','dbrooks@meridianptdallas.com'),('Evergreen Athletics','reggie@evergreenathletics.com'),('Tran Auto Detailing','greg.tran.detail@gmail.com'),('Willow Family Therapy','bbrooks@willowfamilytherapy.com'),('Hillcrest Coffee Roasters','joy@hillcrestcoffee.com'),('Crown Roofing Co','mateo@crownroofingco.com'),('Oakcliff Realty Group','raj@oakcliffrg.com'),('Kind Hands Home Care','aisha@kindhandshomecare.com'),("Cole's Auto Spa",'omar@colesautospa.com')]
EMAIL={e:n for n,e in CANON}
EMAIL.update({'lena.moore.mail@gmail.com':'Bold & Brave Podcast','office@trandental.con':'Tran Dental','reggie@evergreengym.co':'Evergreen Athletics','frisco@maplemedspa.com':'Maple Med Spa','sofia@priceinsures.com':'Price Insurance Group'})
PAYER='Northstar Media Co'
EMAIL['angela@northstarmktg.com']=PAYER
names={n:{n} for n,e in CANON};names[PAYER]={PAYER,'NORTHSTAR MEDIA CO LLC'}
def add(n,s):
 if s:names[n].add(s)
# Non-payer email assignments collect all spelling variants from linked rows.
for rows,nk,ek in [(bookings,'client_name','email'),(invoices,'bill_to','email'),(payments,'payer','payer_email'),(leads,'business','email')]:
 for r in rows:
  n=EMAIL.get(r[ek].lower())
  if n and n!=PAYER:
   add(n,r[nk])
   if rows is leads:add(n,r['name'])
  elif n==PAYER and rows is not bookings:add(n,r[nk])
# Recipient rather than payer defines booking identity.
def client_booking(r):
 if r['email']=='angela@northstarmktg.com':
  return 'Sunset Pediatrics' if 'sunset' in r['client_name'].lower() else 'Meridian Physical Therapy'
 return EMAIL[r['email'].lower()]
for b in bookings:add(client_booking(b),b['client_name'])
# Additional board variants are connected by shoot_booking.
B={b['booking_id']:b for b in bookings}
for r in board:
 if r['shoot_booking']:add(client_booking(B[r['shoot_booking']]),r['client'])
# Resolve all names, including board rows without shoot links.
add('Crown Roofing Co','Crown Roofing')
NAME={norm(v):n for n,vs in names.items() for v in vs}
unknown=[]
for r in board:
 if norm(r['client']) not in NAME:unknown.append(r['client'])
assert not unknown,unknown
# Add explicit sender alias names and blank-email bank payer identities.
NAME[norm('MATEO CASTILLO')]='Crown Roofing Co';NAME[norm('LENA MOORE')]='Bold & Brave Podcast'
for r in payments:
 n=EMAIL.get(r['payer_email'].lower()) or NAME.get(norm(r['payer']))
 assert n,r
 r['_client']=n;r['_amount']=money(r['amount']);r['_date']=datetime.strptime(r['date'],'%d/%m/%Y').date()
for r in invoices:
 r['_client']=EMAIL[r['email']];r['_amount']=money(r['amount']);r['_balance']=r['_amount'];r['_payments']=[];r['_date']=date.fromisoformat(r['issued'])
 if r['status']=='void':r['_balance']=Decimal(0)
I={r['invoice_no']:r for r in invoices}
# Explicit bank references are allocated first globally; otherwise FIFO would steal a payment from a referenced invoice.
unmatched=[];allocations=[]
def allocate(p, inv,amount,rule):
 inv['_balance']-=amount;inv['_payments'].append({'payment':p['payment_id'],'amount':float(amount),'rule':rule})
 allocations.append({'payment':p['payment_id'],'invoice':inv['invoice_no'],'amount':float(amount),'rule':rule})
for p in payments:
 p['_remaining']=p['_amount']
 refs=re.findall(r'INV-\d+',p['reference'])
 if refs:
  for ref in refs:
   inv=I[ref]
   assert inv['_client']==p['_client'],(p,inv)
   if inv['status']=='void':continue
   a=min(p['_remaining'],inv['_balance']);allocate(p,inv,a,'explicit bank reference');p['_remaining']-=a
# For nonreferences, use client + amount / bank period label, then earliest unreserved invoice. Do NOT infer cash from paid flag.
for p in payments:
 if not p['_remaining']:continue
 candidates=[r for r in invoices if r['_client']==p['_client'] and r['status']!='void' and r['_balance']>0 and r['_date']<=p['_date']]
 period=re.search(r'Northstar (Jun|Jul|Aug|Sep) invoices',p['reference'])
 if period:
  mo={'Jun':6,'Jul':7,'Aug':8,'Sep':9}[period[1]];candidates=[r for r in candidates if r['_date'].month==mo]
 if 'august sessions' in p['reference'].lower():candidates=[r for r in candidates if r['_date'].month==8]
 exact=[r for r in candidates if r['_balance']==p['_remaining']]
 # All candidates are already ordered by date except duplicate at end.
 candidates=sorted(candidates,key=lambda r:(r['_date'],r['invoice_no']))
 if exact and not period and 'august sessions' not in p['reference'].lower():
  inv=sorted(exact,key=lambda r:(r['_date'],r['invoice_no']))[0];a=p['_remaining'];allocate(p,inv,a,'identity + exact amount + chronological unreserved invoice');p['_remaining']=Decimal(0)
 else:
  for inv in candidates:
   a=min(p['_remaining'],inv['_balance']);allocate(p,inv,a,'identity + bank period' if period or 'august sessions' in p['reference'].lower() else 'identity + chronological unreserved invoice');p['_remaining']-=a
   if not p['_remaining']:break
 if p['_remaining']:unmatched.append({'payment':p['payment_id'],'client':p['_client'],'amount':float(p['_remaining']),'reference':p['reference']})
# Caution canceled booking invoice B146 has no matching extra cash: retain separately as disputed/noncollectible.
cancelled=[]
for inv in invoices:
 ids=re.findall(r'B\d{3}',inv['memo'])
 for bid in ids:
  if B[bid]['status']=='cancelled':cancelled.append(inv['invoice_no'])
overdue=[{'client':i['_client'],'invoice':i['invoice_no'],'amount_owed':float(i['_balance']),'days_late':(TODAY-date.fromisoformat(i['due'])).days} for i in invoices if i['_balance']>0 and date.fromisoformat(i['due'])<TODAY and i['invoice_no'] not in cancelled]
wrong=[]
for i in invoices:
 truth='paid' if i['_balance']==0 else ('partial' if i['_balance']<i['_amount'] else 'unpaid')
 if i['status']!='void' and i['status']!=truth:
  wrong.append({'invoice':i['invoice_no'],'tool_says':i['status'],'truth':truth+f"; balance ${i['_balance']:.2f}",'how_you_know':'; '.join(f"{p['payment']} ${p['amount']:.2f} ({p['rule']})" for p in i['_payments']) or 'No matching bank receipt exists after reserving explicit invoice references.'})
# One-to-one invoice-to-booking matching. Explicit booking IDs first; exact service date second; then client/service/chronology.
matched={};invoice_booking={};match_evidence=[]
for i in invoices:
 if i['status']=='void' or 'Monthly retainer' in i['memo']:continue
 ids=re.findall(r'B\d{3}',i['memo'])
 if ids:
  assert len(ids)==1;iid=ids[0];matched[iid]=i['invoice_no'];invoice_booking[i['invoice_no']]=iid
  match_evidence.append({'invoice':i['invoice_no'],'booking':iid,'rule':'explicit booking ID in memo','confidence':'high'})
for i in sorted(invoices,key=lambda r: (not bool(re.search(r'(\d{1,2})/(\d{1,2})(?:\s|$)',r['memo'])),r['_date'])):
 if i['status']=='void' or 'Monthly retainer' in i['memo'] or i['invoice_no'] in invoice_booking:continue
 c=i['_client'];amt=i['_amount']
 candidates=[b for b in bookings if b['booking_id'] not in matched and b['status']!='upcoming' and (client_booking(b)==c or c==PAYER and client_booking(b) in ['Sunset Pediatrics','Meridian Physical Therapy']) and money(b['price'])==amt]
 service_date=re.search(r'(\d{1,2})/(\d{1,2})(?:\s|$)',i['memo'])
 if service_date:
  d=date(2026,int(service_date[1]),int(service_date[2]));cand=[b for b in candidates if datetime.strptime(b['date'],'%m/%d/%Y').date()==d]
  assert cand,(i['invoice_no'],cand)
  if len(cand)>1:match_evidence.append({'invoice':i['invoice_no'],'candidates':[x['booking_id'] for x in cand],'uncertainty':'Same payer, day and price: arbitrary pairing within a fully covered group; do not treat as proven client allocation.'})
  b=cand[0]
  rule='payer/client + exact service date + amount'
 else:
  candidates=[b for b in candidates if (datetime.strptime(b['date'],'%m/%d/%Y').date()-i['_date']).days<=7]
  # take recent unbilled booked event; normal invoice delay <= 4 days. Larger delays are review candidates.
  candidates.sort(key=lambda b:(datetime.strptime(b['date'],'%m/%d/%Y').date()>i['_date'],abs((datetime.strptime(b['date'],'%m/%d/%Y').date()-i['_date']).days)))
  assert candidates,(i['invoice_no'],i)
  b=candidates[0]
  rule='payer/client + amount + nearest preceding unmatched booking (unique prebilling within 7 days allowed)'
 match_evidence.append({'invoice':i['invoice_no'],'booking':b['booking_id'],'rule':rule,'confidence':'inferred','issue_to_service_days':(i['_date']-datetime.strptime(b['date'],'%m/%d/%Y').date()).days})
 matched[b['booking_id']]=i['invoice_no'];invoice_booking[i['invoice_no']]=b['booking_id']
never=[]
for b in bookings:
 if b['status']=='completed' and money(b['price'])>0 and b['booking_id'] not in matched:
  never.append({'client':client_booking(b),'booking_id_or_month':b['booking_id'],'amount':float(money(b['price']))})
# Retainer contract month expectation anchored on earliest invoice + 0-price shoot. April shoots support May-start invoices; no April fee invented.
# All documented invoiced months exist. Check Horizon pricing discrepancy separately.
clients=[]
for n,e in CANON:
 es=sorted(k for k,v in EMAIL.items() if v==n)
 phones=sorted({r['phone'] for r in leads if EMAIL.get(r['email'])==n and r['phone']})
 if n=='Maple Med Spa':phones.append('972-555-0182')
 aliases=sorted(v for v in names[n] if v!=n and not v.isupper())
 clients.append({'name':n,'other_names_used_in_the_data':aliases,'emails':es,'phones':phones})
# Financial contribution = completed booking expected revenue + monthly retainers (except future Oct) minus modeled studio + all recorded edit hours.
# Include editing work in progress already recorded; no acquisition overhead available.
rates={r['name']:money(r['pay'].split('/')[0]) for r in team if r['pay']}
revenue=collections.defaultdict(Decimal);studio=collections.defaultdict(Decimal);editing=collections.defaultdict(Decimal)
for b in bookings:
 if b['status']!='completed':continue
 n=client_booking(b);revenue[n]+=money(b['price'])
 hrs={'Content Day':6,'Reels Pack':3,'Retainer Shoot':4,'Podcast Studio 2hr':2,'Podcast Studio 4hr':4}[b['service']]
 studio[n]+=Decimal(hrs)*40
for i in invoices:
 if 'Monthly retainer' in i['memo'] and i['_date'].month<10:revenue[i['_client']]+=i['_amount']
for r in board:editing[NAME[norm(r['client'])]]+=Decimal(r['editor_hours'])*rates[r['editor']]
channel={}
for n,e in CANON:
 relevant=[r for r in leads if EMAIL.get(r['email'])==n]
 channel[n]=sorted(relevant,key=lambda r:r['created'])[0]['source']
metrics=[]
for n,e in CANON:
 metrics.append({'client':n,'channel':channel[n],'earned_revenue':float(revenue[n]),'studio_cost':float(studio[n]),'editing_cost':float(editing[n]),'contribution':float(revenue[n]-studio[n]-editing[n])})
channels=[]
for c in sorted(set(channel.values())):
 rows=[r for r in metrics if r['channel']==c]
 channels.append({'channel':c,'clients':len(rows),'earned_revenue':round(sum(r['earned_revenue'] for r in rows),2),'studio_cost':round(sum(r['studio_cost'] for r in rows),2),'editing_cost':round(sum(r['editing_cost'] for r in rows),2),'contribution':round(sum(r['contribution'] for r in rows),2),'contribution_per_client':float((sum(Decimal(str(r['contribution'])) for r in rows)/len(rows)).quantize(Decimal('.01'),rounding=ROUND_HALF_UP))})
disputed=[{'client':'Oak Cliff Realty LLC','invoice':'INV-1135','booking':'B146','amount':1500,'reason':'B146 is cancelled; September 25 09:57 WhatsApp says already paid and asks to reschedule. The only three $1500 receipts, P5044/P5070/P5116, explicitly pay separate completed sessions INV-1030/1079/1132. No fourth receipt exists. Hold collection/refund; obtain prepayment proof and decide credit/reshoot versus void. This $1500 is excluded from confirmed overdue and confirmed credit.'}]
result={'as_of':str(TODAY),'client_count':len(clients),'clients':clients,'payers_who_are_not_clients':[{'name':PAYER,'pays_for':['Sunset Pediatrics','Meridian Physical Therapy']}],'overdue':overdue,'overdue_total':sum(r['amount_owed'] for r in overdue),'we_owe':unmatched,'never_billed':never,'never_billed_total':sum(r['amount'] for r in never),'billing_tool_is_wrong':wrong,'cancelled_invoices':cancelled,'disputed':disputed,'booking_match_evidence':match_evidence,'allocations':allocations,'invoice_booking':invoice_booking,'channels':channels,'client_contribution':metrics,'identities':{'email':EMAIL,'name':NAME}}
(OUT/'seed-identities.json').write_text(json.dumps({'clients':clients,'payers':[{'name':PAYER,'aliases':sorted(names[PAYER]),'emails':['angela@northstarmktg.com'],'phones':['817-555-0140'],'pays_for':['Sunset Pediatrics','Meridian Physical Therapy']}]},indent=2))
(OUT/'invoice-booking-bridge.json').write_text(json.dumps({'mapping':invoice_booking,'evidence':match_evidence},indent=2))
(OUT/'result.json').write_text(json.dumps(result,indent=2))
(OUT/'reconciliation.json').write_text(json.dumps([{'invoice':i['invoice_no'],'client':i['_client'],'amount':float(i['_amount']),'balance':float(i['_balance']),'status':i['status'],'payments':i['_payments']} for i in invoices],indent=2))
print(json.dumps({k:v for k,v in result.items() if k not in ['clients','allocations','identities','invoice_booking','client_contribution','booking_match_evidence']},indent=2))
