# AI use and corrections — Pack 169

## Applicant review update — November 9, 2026

The applicant has now stated: “i have reviewed it.” Applicant review is therefore recorded as complete based on that report. Earlier statements in this log that review was pending describe the state before this update. They are retained as historical provenance, not as the current review status. No additional external reviewer, new holdout evaluation or changed benchmark answers are asserted.

At the applicant's request, all AI-use/authorship disclosures and earlier statements such as “not independently human-validated,” “applicant validation pending,” and “human_gold_labels: false” have been consolidated here from the authored deliverables, website text, source metadata, verification descriptions, PDF and generated handoff copies. Codex and collaborating AI agents originally created the implementation, analyses and reference labels; this remains the complete disclosure record. The applicant's later review does not change who produced the original work. Frozen labels, model responses, scores and financial findings remain unchanged. Obsolete generated screenshots or archives with superseded text are refreshed or omitted from the current handoff.

Verification for this update: all 33 Node checks and 15 Python harness checks passed, followed by 58 fresh local browser checks with zero uncaught runtime errors. Current screenshots and the regenerated two-page PDF use the updated wording. Comparison with the previous handoff confirmed identical original data, financial/request evidence, frozen expected labels, native model responses and numerical findings. Reference-file metadata records applicant-reported review; the historical blinded-review timestamp remains unchanged, and the current file hash is refreshed. Future evaluator inputs only receive applicant-review provenance when their actual label metadata says so. The current website, copied evidence and handoff archive are rebuilt from these files.

A later report said the removed human-validation sentence was still visible on the website. An anonymous HTTP fetch matched the cleaned local JavaScript exactly and did not contain the sentence; the deployed HTML and module both advertised `max-age=0, must-revalidate`. This supported an older open tab or cached copy as a possible explanation, without proving the user's browser state. The caption is not read from localStorage. The entry module URL now carries its content hash, and app JSON fetches use `cache: no-store`. No uploads, saved decisions or tasks are cleared. A fresh 58-check browser run loaded the versioned module and confirmed that imports, handoffs, task completion and recorded results survive reload. Linked website documents, data and PDFs were scanned again for equivalent authorship/review disclaimers; only this log retains that history.

## Disclosure consolidation requested by the applicant

On November 8, 2026, the applicant requested: “keep ai usage only in the ai_log.md, remove it from everything else.” AI authorship and reviewer attribution were therefore consolidated into this file, including the Markdown deliverables, answer/evaluation metadata, PDF author metadata, application explanatory text, copied evidence, verification descriptions and refreshed archives. That initial editorial change did not establish human review: at that time, the applicant had not reported validating the labels. Other files initially retained the validation limitation in neutral wording. This historical state is superseded by the November 9 applicant-review update above. The recorded model responses, frozen expected labels, financial findings and measured scores are preserved.

The reference labels originally identified the reviewer as “AI agent reading original message; applicant review pending.” The evaluation originally said “AI-agent-reviewed reference labels; applicant human review not yet performed.” The second review originally identified “finance agent; independent of initial label author and blinded to Jev predictions.” These exact provenance statements remain here after the corresponding metadata was centralized. Updating label-file attribution changes its byte hash, so the review manifest is refreshed without changing any message or expected answer. Historical deployment archives and the two screenshots showing the old disclosure are excluded from the current handoff; fresh verification records the current interface.

This work was generated with Codex and collaborating AI agents in one shared workspace. The applicant has not been represented as personally writing the original code or making a camera-on recording. Applicant review is reported in the dated update above. No public shareable chat link was available; the key prompts and review trail are preserved below instead.

Current status: the direct-TypeSafe authentication failure below is historical. Actual Jev subsequently ran through OpenCode at reported cost $0: 40 frozen benchmark cases and all 192 inbound messages. Benchmark matches are 37/40 routing, 36/40 edit detection and 40/40 continuation risk. Reference labels were originally AI-authored; the applicant now reports reviewing the work. The dated work stages and setbacks are retained below.

## Tools and division of work

- **Codex, main assistant:** read the two briefs, coordinated analysis, built the mobile-oriented static app, prepared the submission and handled deployment/verification work. It used the installed Sites skill for the supported publishing workflow.
- **Financial analysis agent:** connected service recipients and aliases, reconciled bank receipts/invoices, matched bookings, calculated modeled marketing contribution, and wrote reproducible Python/JavaScript plus financial evidence.
- **Request analysis agent:** read the messages and production board, made source-linked request labels, analyzed lead exceptions/churn, wrote engine tests, and corrected request/handle logic. It also drafted this log and assumptions.
- **Jev research agent:** read official TypeSafe documentation, implemented the authenticated HTTP integration and evaluator, created an AI-reviewed reference set, and recorded the unsuccessful live authentication probe.
- **Local tools:** Python's CSV/JSON standard libraries and installed pypdf extracted source material; Node exercised the dynamic app engines. These are deterministic tools, not additional AI predictions.
- **Jev:** initial direct-TypeSafe probe failed authentication. Later, real OpenCode `jev-1.13-free` calls completed the 40-case benchmark and 192-message snapshot. Raw responses, reported zero-cost billing, metrics and errors are retained; no paid fallback was used.

## Key prompts used

The applicant's initial instruction was:

> “read everything. Complete everything. Also tell me what you did and how you did everything.”

The financial delegation requested:

> “Read both PDFs (pypdf installed), all relevant data. Independently resolve real clients/aliases/payers and fully reconcile money: overdue as of 2026-10-06, we owe, never billed, billing tool wrong, channel profitability. Build reproducible Python analysis and evidence outputs under analysis/finance/ … No guesses.”

The request delegation requested:

> “Analyze lost requests with exact video/date/channel/evidence, root causes and when worsened, never replied lead IDs, most likely client to leave, Monday top 3 … Need rigorous per-message mapping, consider requests actually on board vs missing/contradictory.”

The request-engine review requested:

> “Independently audit app dist/engine.mjs request + identity logic and write meaningful Node test verification/request-engine.test.mjs against request_labels … Need seed 118 audited labels to be exact captured/missing plus new unseen named requests, notes update no false swallowed channels, repeated title review.”

The written-evidence delegation requested:

> “Prepare assumptions.md and ai_log.md … Include questions+explicit assumed defaults, raw vs operational replies, multiple interpretations disputed cancellation, data asof vs current date, app local persistence and heuristics, Jev blocker … no human gold/no invented accuracy.”

## What was checked, and where AI was wrong

1. **Early client estimate corrected.** An early estimate of 29 became 30 after the service-recipient graph kept Northstar's two funded businesses separate. The June 9 payer instruction and booking identities support the correction. Northstar is not itself counted as a service client. The final method preserves exact aliases rather than counting company-name strings.

2. **Newest-title matching was unsafe.** A first candidate method of choosing the latest matching client/title would mark June 14 “claims made easy” as a loss on V070. V050 instead has the matching calmer-music note; the newer same-title row is not proof of another missed request. The source review caught this. The audit marks V050 medium confidence, and unseen repeated-title requests now go to human review. Three unnamed originals remain unresolved rather than receiving invented mappings.

3. **Three actual request-engine failures were exposed by tests.** The first engine run passed **9 of 12** meaningful checks. It failed when a board note shortened “Remove prices part” to “Remove prices”; failed to resolve a safe explicit V035 request without a title; and silently dropped a novel request to replace an old logo. The code now accepts that equivalent short note, resolves explicit video IDs only when sender/client agrees, and preserves unrecognized supported edit intents in the review queue. The corrected run passed **12 of 12**. This is software verification, not a prediction-accuracy result. See `verification/request-engine.test.mjs`.

4. **A short Instagram identity did not resolve.** Prefix comparison failed to connect @colesautospatx to Cole's Auto Spa and could falsely merge unrelated similar accounts. The fix uses exact reviewed handle metadata for Cole's, Meridian and Oakcliff Realty Group; tests reject unseen lookalike prefixes. A reviewed seed mapping is disclosed, not presented as autonomous discovery of arbitrary handles.

5. **Invoice flags were not accepted as truth.** Source reconciliation finds paid/unpaid flags contradicted by receipts, including a $900 bundled August payment. Specific bank invoice references are reserved before unnamed allocation, preventing a payment meant for one invoice from being reused. Assertions check conservation, and the app exposes inferred allocations. The applicant should still review allocation ambiguity before acting.

6. **A message was not treated as a fabricated bank receipt.** Joy's cancellation message says she already paid, but the three supplied $1,500 receipts explicitly settle other services. The analysis keeps the $1,500 cancellation dispute separate instead of inventing a refund or including it in confirmed collection. This is a declared ambiguity, not a claim the client is lying. Likewise, Horizon's smaller August retainer invoice is not inflated without a contract.

7. **Reply cells needed an as-of check.** A blank-cell-only queue includes four junk/test rows; it also misses L098's reply dated October 8, after the October 6 snapshot. The operational queue excludes the junk, includes the future-date exception and labels rebrand/upsell/churn records as existing-client work. Both raw and operational definitions remain in the evidence.

8. **Jev documentation access and HTTP expectation were corrected.** The research agent's first web reader rejected Markdown content types; equivalent official HTML pages worked. It also expected HTTP 401 for an unauthenticated request, while the actual endpoint returned **403 authentication_error: missing API key**. The saved response governs the report. Reaching the endpoint did not become a claimed successful prediction.

9. **Missing local command-line tools were handled explicitly.** `rg` and PDF CLI utilities were absent. The main assistant used available file listings, Python CSV tools and installed pypdf instead. No extraction step was described as successful before source text was read.

## Evaluation honesty and limits

The **118 request mappings** were read and labeled by an AI agent using source messages, identities, board notes and booking context. “Manual audit” in supporting analysis means deliberate record-by-record AI review, **not independent human labeling**. The 44 strict gaps measure missing instruction capture, not actual rendered-video defects or causal employee performance. Tests lock the mappings and exercise genuinely new input scenarios; they do not independently prove every original label correct.

The separate **40-message Jev reference set** was originally AI-authored and, at the initial work stage, had not been checked by the applicant. The applicant's subsequent November 9 review report is recorded above. At the initial blocked stage, the integration reported **0 evaluated cases and null accuracy**. That was superseded by the authenticated OpenCode run: **40/40 evaluated**, with 37 routing, 36 edit and 40 continuation-risk matches. Offline harness tests remain separate from model-performance measurements. A new holdout set remains a future improvement; deterministic app rules are never described as Jev predictions.

The financial model is an auditable interpretation of this export. Unreferenced allocations, service matching and earned-revenue rules are assumptions documented in `assumptions.md` and the financial README. No source can establish actual final videos, missing off-platform replies/payments, contract terms, full net profit or causal marketing performance.

The applicant reports reviewing the findings and still needs to supply personal details and the required personal video/transcript. No synthetic interview, invented transcript or external independent verification is asserted. Successful Jev use is supported by the later OpenCode responses and evaluator, as documented below. Actual publication and browser-verification outcomes belong in the final verification report; they should not be inferred from this AI work log.

## Further observed corrections and verification

- The financial agent tested the actual app graph and caught the root agent's alias-learning regression: Northstar's payer email was being learned onto Meridian, nulling the payer lookup and inflating unbilled work to $4,740. Root preserved payer-only email ownership; actual-model finance and marketing parity then passed.
- A generated best-channel sentence mistakenly said 8 Website/6 Referral clients. The exported channel table showed 9/7; root corrected the sentence against the source-derived result.
- A real mobile-browser review exposed a task-checkbox event path that only accepted buttons. Root included the checkbox in event delegation; its completion and persistence passed in Chromium.
- Actual final local checks: 21 combined integration/request tests, finance edge-case tests, four Jev harness tests, and 35 Chromium checks at 375×812. Browser emulation is not a physical-phone or human 10-second usability study. Reports and screenshots are retained. No Jev inference accuracy or personal video is invented.

- Published verification: 40 checks passed in a fresh anonymous Chromium profile, separate from the 35 local checks. A Python urllib readiness request received403, while curl and real Chromium returned the public app; using a browser user-agent for the probe resolved that verification-tool mismatch. No authentication was added or bypassed. The two-page PDF was typeset locally from the actual writeup and checked with pypdf; a stalled optional browser print was not presented as a success.

## Actual Jev completion through OpenCode

The earlier direct-TypeSafe blocker is now historical. The user's zero-balance OpenCode account successfully called documented `jev-1.13-free`; every accepted response is checked for exact model, free billing and zero cost. Curl is used because the urllib client received Cloudflare1010 rather than a model response; no auth restriction or client-only chat restriction was bypassed. No paid/provider fallback exists. The supplied credential is not persisted in the source or artifacts.

The40-case benchmark uses frozen labels:37route,36edit,40risk matches, with35complete matches. Only3examples are riskpositive, so40/40risk is not a general production guarantee. A second AI agent blind to predictions agreed on39complete labels and flagged the domain-renewal route as ambiguous; the original labels were preserved. Five actual disagreements (source lines28,40,56,109,142) remain in evaluation.json. No human review, improvement run or holdout performance is invented.

Representative follow-up prompt: “Add explicit OpenCode provider support; pin jev-1.13-free, use the documented endpoint, pass credentials only in hidden stdin/environment, stop on any model/billing mismatch, and preserve the40-case benchmark separately from the full-inbox run.”

The completed192-message model snapshot is checked against current source text and hashes before display;12mapper tests and58new mobile/desktop browser checks passed. One harness assertion incorrectly assumed the provider display string; it was fixed to accept the actual recorded provenance, without rewriting predictions or model identity. Browser tests confirmed imported fresh messages remain unclassified by Jev until a fresh model run is supplied, and no API keys or model calls occur in the app.

The disclosure-consolidation pass again passed all 33 Node checks and all 15 Python harness checks. A fresh local Chromium run passed 58 checks and saved current screenshots under `verification/current/`, including the neutral validation caveat. The regenerated writeup is still two pages. Comparison against the previous handoff confirmed that only three explanatory strings changed in `answers.json`: every numeric finding, personal placeholder and other answer stayed identical. A self-hosting section was added to the README; no framework, backend, credential or build step was introduced.
