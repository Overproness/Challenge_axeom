# Anonymous published-app verification

The actual live app at https://axeom-169-57w5zx10lf.qaimforfiverrmine.chatgpt.site was tested in a fresh Chromium profile, with no cookies, login, or prior browser state. All **40 checks passed**, including all eight runtime assets returning HTTP 200 and no uncaught JavaScript errors. Screenshots include a 375 × 812 mobile viewport and a 1440 × 1000 desktop viewport.

The tests imported six synthetic files that were never in the supplied pack. They verified automatic client linking, a precisely $1,000 change in overdue balance after a partial bank payment, a new lead and edit request, cancel/approve behavior, duplicate-file idempotency, the connected client profile, an assigned handoff, persisted task completion, correction of an existing bank payment, atomic rejection of an invalid batch, and reload persistence.

A separate novel edit — replacing the opening logo on an explicitly named video — went into owner review. The owner selected its video and approved the handoff. It left the ambiguous queue, retained its explicit mapping and original instruction, and remained correctly mapped after reload. Test data stayed in the temporary browser profile and did not alter the public seed data.

`report.json` contains the actual checks, network responses, and state snapshots. PNGs show the deployed interface. The temporary test browser was closed afterward.

One access difference was observed: Python's default urllib user agent initially received HTTP 403, before Chromium launched. The browser-user-agent readiness probe then returned HTTP 200, and fresh Chromium successfully loaded the complete app anonymously. This is consistent with user-agent filtering; the precise cause was not established. No login was required in the browser.

An optional Chromium PDF print attempt was blocked by sandbox browser restrictions. Its escalation request remained pending for approximately 547 seconds and was then aborted by the user. That print attempt did not produce a PDF. This approval delay did not affect the completed published-app checks. The submission PDF was generated and checked separately.

Reproduce the published checks with the installed Chromium and Python websocket-client:

```sh
python3 verification/browser_qa.py --url https://axeom-169-57w5zx10lf.qaimforfiverrmine.chatgpt.site --out verification/published --novel-request
```

Browser emulation does not replace a physical-phone usability study. These results validate the deployed app version present at the report's timestamp; publication after that timestamp is a separate deployment.
