"""Typeset the real writeup locally; no browser, network or added dependencies."""
from pathlib import Path
import re
from PIL import ImageFont
from pypdf import PdfWriter, PdfReader
from pypdf.generic import DictionaryObject, NameObject, DecodedStreamObject

ROOT=Path(__file__).resolve().parents[1]
WIDTH,HEIGHT=595.28,841.89
MARGIN=48

def clean(s):
    return s.replace('**','').replace('`','').replace('\u2212','-').replace('\u2011','-')

def pdf_string(s):
    # Standard PDF fonts use WinAnsi; escape every non-ASCII byte explicitly.
    out=''
    for c in s.encode('cp1252',errors='strict'):
        out+=('\\'+chr(c)) if c in (40,41,92) else chr(c) if 32<=c<=126 else '\\%03o'%c
    return '('+out+')'

def wrap(s,size,bold=False):
    # DejaVu metrics are a conservative width estimate for PDF Helvetica.
    font=ImageFont.truetype('DejaVuSans-Bold.ttf' if bold else 'DejaVuSans.ttf',round(size*10))
    lines=[];line=''
    for word in s.split():
        candidate=(line+' '+word).strip()
        if font.getlength(candidate)/10>(WIDTH-2*MARGIN)*.97 and line:
            lines.append(line);line=word
        else:line=candidate
    if line:lines.append(line)
    return lines

def main():
    blocks=[]
    for block in (ROOT/'writeup.md').read_text().split('\n\n'):
        block=block.strip()
        if not block:continue
        level=2 if block.startswith('## ') else 1 if block.startswith('# ') else 0
        text=clean(re.sub(r'^#{1,2}\s+','',block).replace('\n',' '))
        blocks.append((level,text))
    pages=[[]];y=HEIGHT-MARGIN
    for level,text in blocks:
        size=18 if level==1 else 12 if level==2 else 10.2
        leading=22 if level==1 else 16 if level==2 else 13.6
        lines=wrap(text,size,level>0)
        if level and y<MARGIN+70:pages.append([]);y=HEIGHT-MARGIN
        if level==2:y-=5
        for line in lines:
            if y-leading<MARGIN:pages.append([]);y=HEIGHT-MARGIN
            color='0.09 0.24 0.21' if level else '0.14 0.19 0.18'
            pages[-1].append(f'{color} rg BT /F{2 if level else 1} {size} Tf 1 0 0 1 {MARGIN} {y-size:.2f} Tm {pdf_string(line)} Tj ET')
            y-=leading
        y-=8 if not level else 6
    assert len(pages)<=2,f'Writeup would be {len(pages)} pages; do not truncate.'
    writer=PdfWriter()
    fonts={}
    for key,name in [('F1','Helvetica'),('F2','Helvetica-Bold')]:
        fonts[NameObject('/'+key)]=writer._add_object(DictionaryObject({NameObject('/Type'):NameObject('/Font'),NameObject('/Subtype'):NameObject('/Type1'),NameObject('/BaseFont'):NameObject('/'+name),NameObject('/Encoding'):NameObject('/WinAnsiEncoding')}))
    for i,lines in enumerate(pages):
        page=writer.add_blank_page(width=WIDTH,height=HEIGHT)
        page[NameObject('/Resources')]=DictionaryObject({NameObject('/Font'):DictionaryObject(fonts)})
        lines.append(f'0.45 0.49 0.46 rg BT /F1 8 Tf 1 0 0 1 {MARGIN} 27 Tm {pdf_string("AXEOM PACK 169  |  DATA: OCTOBER 6, 2026  |  "+str(i+1)+" / "+str(len(pages)))} Tj ET')
        stream=DecodedStreamObject();stream.set_data(('\n'.join(lines)).encode('ascii'))
        page[NameObject('/Contents')]=writer._add_object(stream)
    writer.add_metadata({'/Title':'Axeom Pack 169 — Writeup','/Author':'Applicant identity pending'})
    path=ROOT/'writeup.pdf';writer.write(path)
    reader=PdfReader(path)
    printed=' '.join(' '.join(p.extract_text().split()) for p in reader.pages)
    for marker in ['30 real clients','$11,050','40/40','Week 2','no recording or transcript is invented']:
        assert marker in printed,marker
    print(f'{path}: {len(reader.pages)} pages, all content markers verified')

if __name__=='__main__':main()
