import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {build, identities, importFiles, parseMessages} from '../axeom-desk/dist/engine.mjs';

const seed=JSON.parse(await readFile(new URL('../axeom-desk/dist/seed.json',import.meta.url),'utf8'));
const reviewed=JSON.parse(await readFile(new URL('../axeom-desk/dist/identities.json',import.meta.url),'utf8'));
const labels=JSON.parse(await readFile(new URL('../analysis/requests/request_labels.json',import.meta.url),'utf8'));
const clone=()=>structuredClone(seed);
const append=(data,line)=>{data.messages+='\n'+line;return data;};
const run=data=>build(data,reviewed,labels);

test('all 118 audited requests retain their video mapping and capture decision',()=>{
  assert.equal(labels.length,118);
  const result=run(seed);
  for(const label of labels){
    const actual=result.requests.filter(r=>r.raw===label.message);
    assert.equal(actual.length,1,'Message line '+label.message_line+' must be retained exactly once');
    assert.equal(actual[0].video_id,label.video_id,'Wrong video at message line '+label.message_line);
    assert.equal(actual[0].captured,label.capture_status==='captured','Wrong capture at message line '+label.message_line);
  }
  assert.equal(result.lost.filter(r=>labels.some(l=>l.message===r.raw)).length,44);
});

test('all pack messages parse without losing voice transcript text or outbound direction',()=>{
  const parsed=parseMessages(seed.messages);
  assert.equal(parsed.length,194);
  const voice=parsed.find(m=>m.line===19);
  assert.equal(voice.channel,'voice note');
  assert.match(voice.body,/Insurance we take.*walk-ins welcome/);
  assert.equal(parsed.find(m=>m.line===128).direction,'to');
  assert.equal(parsed.find(m=>m.line===193).channel,'whatsapp');
  assert.match(parsed.find(m=>m.line===193).body,/canción/);
});

test('repaired board notes recompute the original missing request rather than freeze the audited answer',()=>{
  const data=clone();data.production_board.find(v=>v.video_id==='V035').notes_on_board='Add walk-ins welcome';
  const result=run(data);
  assert.equal(result.requests.find(r=>r.video_id==='V035').captured,true);
  assert.equal(result.lost.some(r=>r.video_id==='V035'),false);
});

test('a matching semantic short note also captures a remove-prices instruction',()=>{
  const data=clone();data.production_board.find(v=>v.video_id==='V028').notes_on_board='Remove prices';
  assert.equal(run(data).requests.find(r=>r.video_id==='V028').captured,true);
});

test('new unseen client, booking, board row and message link without a hand-authored identity',()=>{
  const data=clone();
  data.bookings.push({booking_id:'B980',date:'10/05/2026',client_name:'New Clinic',email:'new@clinic.example',service:'Reels Pack',status:'completed',price:'900'});
  data.production_board.push({video_id:'V980',client:'New Clinic',title:'Clinic welcome',editor:'Ali',stage:'In edit',notes_on_board:'Captions bigger',revisions:'0',editor_hours:'1',client_approved_on:'',shoot_booking:'B980'});
  append(data,'[2026-10-06 08:00] EMAIL from new@clinic.example: Please make the captions bigger on Clinic welcome.');
  const request=run(data).requests.find(r=>r.video_id==='V980');
  assert.ok(request);assert.equal(request.client,'New Clinic');assert.equal(request.captured,true);
});

test('repeated titles on unseen messages go to review instead of choosing the newest video',()=>{
  const data=append(clone(),'[2026-10-06 08:01] EMAIL from rtran@horizonwp.com: Please make the captions bigger on retirement myths.');
  const result=run(data);const raw=data.messages.split('\n').at(-1);
  assert.equal(result.requests.some(r=>r.raw===raw),false);
  assert.ok(result.ambiguous.some(r=>r.raw===raw&&/Repeated title/.test(r.why)));
});

test('an explicit video ID safely resolves an unseen edit without its title',()=>{
  const data=append(clone(),'[2026-10-06 08:02] EMAIL from vlopez@summitptdallas.com: Please make the captions bigger on V035.');
  const request=run(data).requests.find(r=>r.raw===data.messages.split('\n').at(-1));
  assert.ok(request);assert.equal(request.video_id,'V035');assert.equal(request.captured,false);
});

test('a video ID belonging to a different sender never creates a silent cross-client match',()=>{
  const data=append(clone(),'[2026-10-06 08:03] EMAIL from rtran@horizonwp.com: Please make the captions bigger on V035.');
  const result=run(data);const raw=data.messages.split('\n').at(-1);
  assert.equal(result.requests.some(r=>r.raw===raw),false);assert.ok(result.ambiguous.some(r=>r.raw===raw));
});

test('a novel edit instruction naming a video stays visible for human review',()=>{
  const data=append(clone(),'[2026-10-06 08:04] EMAIL from office@trandental.com: Please replace the old logo in Office tour.');
  const raw=data.messages.split('\n').at(-1);const result=run(data);
  assert.ok(result.ambiguous.some(r=>r.raw===raw&&/Unrecognized edit instruction/.test(r.why)));
});

test('future requests are excluded using the challenge date',()=>{
  const data=append(clone(),'[2026-10-07 08:05] EMAIL from vlopez@summitptdallas.com: Please make the captions bigger on V035.');
  const raw=data.messages.split('\n').at(-1);const result=run(data);
  assert.equal(result.messages.some(r=>r.raw===raw),false);
});

test('reuploading the same messages is idempotent and source failures leave input unchanged',()=>{
  const before=JSON.stringify(seed);
  const uploaded=importFiles(seed,[{name:'messages.txt',text:seed.messages}]);
  assert.equal(parseMessages(uploaded.data.messages).length,194);
  assert.equal(uploaded.report[0].added,0);
  assert.throws(()=>importFiles(seed,[{name:'messages.txt',text:'not a message'}]),/Invalid message/);
  assert.equal(JSON.stringify(seed),before);
});

test('same-name contacts remain separate and known board aliases resolve to the correct client',()=>{
  const graph=identities(seed,reviewed);
  assert.equal(graph.resolve('Dr Tran','office@trandental.con'),'Tran Dental');
  assert.equal(graph.resolve('Dr Patel','hello@pateldental.com'),'Patel Dental');
  assert.notEqual(graph.resolve('Joy Patel','joy@oakcliffrealty.com'),graph.resolve('Raj Sullivan','raj@oakcliffrg.com'));
  assert.equal(graph.sender(parseMessages(seed.messages).find(r=>r.line===109)),'Meridian Physical Therapy');
  assert.equal(graph.sender(parseMessages(seed.messages).find(r=>r.line===121)),'Oakcliff Realty Group');
  assert.equal(graph.sender(parseMessages(seed.messages).find(r=>r.line===126)),"Cole's Auto Spa");
  assert.equal(graph.sender({sender:'@colesautospatx.fake'}),'');
  assert.equal(graph.sender({sender:'@meridianphysicalth_not_reviewed'}),'');
});
