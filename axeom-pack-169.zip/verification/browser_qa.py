#!/usr/bin/env python3
"""Real Chromium mobile QA using CDP. No Playwright or browser installation needed.

Run after serving axeom-desk/dist on 127.0.0.1:8765.
The dedicated temporary browser profile never changes the user's browser data.
"""
from __future__ import annotations
import argparse
import base64
import csv
from datetime import datetime, timezone
import json
from pathlib import Path
import shutil
import subprocess
import tempfile
import time
import urllib.error
import urllib.request

import websocket

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "verification" / "browser"


class CDP:
    def __init__(self, ws_url):
        self.ws = websocket.create_connection(ws_url, timeout=20, suppress_origin=True)
        self.seq = 0
        self.errors = []
        self.responses = []

    def call(self, method, params=None):
        self.seq += 1
        ident = self.seq
        self.ws.send(json.dumps({"id": ident, "method": method, "params": params or {}}))
        while True:
            result = json.loads(self.ws.recv())
            if result.get("method") == "Runtime.exceptionThrown":
                self.errors.append(result["params"]["exceptionDetails"])
            if result.get("method") == "Runtime.consoleAPICalled" and result["params"]["type"] == "error":
                self.errors.append(result["params"])
            if result.get("method") == "Network.responseReceived":
                self.responses.append({k: result['params']['response'][k] for k in ('url', 'status')})
            if result.get("id") == ident:
                if "error" in result:
                    raise RuntimeError(result["error"])
                return result.get("result", {})

    def evaluate(self, js):
        response = self.call("Runtime.evaluate", {"expression": js, "returnByValue": True, "awaitPromise": True})
        if response.get("exceptionDetails"):
            raise RuntimeError(response["exceptionDetails"])
        return response.get("result", {}).get("value")

    def wait(self, expression, timeout=15):
        until = time.monotonic() + timeout
        while time.monotonic() < until:
            value = self.evaluate(expression)
            if value:
                return value
            time.sleep(0.1)
        raise TimeoutError(expression)

    def click(self, selector):
        self.evaluate(f"document.querySelector({json.dumps(selector)}).click()")

    def navigate(self, page):
        self.click(f"#navigation a[href='#{page}']")
        self.wait(f"location.hash === '#{page}'")

    def upload(self, paths, selector="#file-input", wait_dialog=True):
        document = self.call("DOM.getDocument")
        node = self.call("DOM.querySelector", {"nodeId": document["root"]["nodeId"], "selector": selector})
        self.call("DOM.setFileInputFiles", {"nodeId": node["nodeId"], "files": [str(p.resolve()) for p in paths]})
        if wait_dialog:
            self.wait("document.querySelector('#dialog').open")

    def screenshot(self, name):
        result = self.call("Page.captureScreenshot", {"format": "png", "captureBeyondViewport": False})
        (OUT / (name + ".png")).write_bytes(base64.b64decode(result["data"]))

    def snapshot(self):
        return self.evaluate("""(async () => {
          const {build}=await import('./engine.mjs');
          const saved=JSON.parse(localStorage.getItem('axeom169-desk-v1')||'null');
          const [seed,ids,audit]=await Promise.all(['seed.json','identities.json','request-audit.json'].map(p=>fetch(p).then(r=>r.json())));
          const d=saved?.data||seed;
          const model=build(d,ids,[...audit,...(saved?.requestLinks||[])],saved?.overrides||{},saved?.asOf||'2026-10-06');
          return {clients:model.entities.filter(e=>!e.payer_only).length, overdue:model.finance.overdue_total,
            unbilled:model.finance.never_billed_total, missing:model.lost.length, waiting:model.waiting.length,
            videos:d.production_board.length, invoices:d.invoices.length, payments:d.payments.length,
            bookings:d.bookings.length, leads:d.leads.length, tasks:saved?.tasks||[], imports:saved?.imports||[],
            ambiguous:model.ambiguous.length,requestLinks:saved?.requestLinks||[],
            qaClient:model.entities.find(e=>e.name==='QA Studio Buyer')||null,
            qaInvoice:model.finance.overdue.find(i=>i.invoice==='INV-9999')||null,
            qaVideo:d.production_board.find(v=>v.video_id==='V999')||null};
        })()""")

    def jev_snapshot(self):
        """Inspect the actual served archive; never fabricate model output for QA."""
        return self.evaluate("""(async () => {
          const {triageForMessages}=await import('./jev-results.mjs');
          const saved=JSON.parse(localStorage.getItem('axeom169-desk-v1')||'null');
          const [seed,archive,evaluation]=await Promise.all(['seed.json','jev-results.json','jev/evaluation.json'].map(p=>fetch(p).then(r=>{if(!r.ok)throw Error(p+' HTTP '+r.status);return r.json();})));
          const t=triageForMessages({...(saved?.data||seed),asOf:saved?.asOf||'2026-10-06'},saved?.jevResults||archive);
          return {available:t.available,provider:t.provider,requested_model:t.requested_model,stats:t.stats,error:t.error,
            models:[...new Set(t.suggestions.map(s=>s.model))],first:t.suggestions[0]||null,
            all_review_only:t.suggestions.every(s=>s.review_required===true&&s.action_authorized===false),
            stored_results:!!saved?.jevResults,evaluation:{evaluated_messages:evaluation.evaluated_messages,
              labeled_messages:evaluation.labeled_messages,accuracy_by_field:evaluation.accuracy_by_field,
              label_provenance:evaluation.label_provenance},
            archive_successes:archive.predictions.filter(p=>p.status==='succeeded').length};
        })()""")


def fixtures(folder):
    folder.mkdir(parents=True, exist_ok=True)
    records = {
        "qa-leads.csv": (["lead_id", "created", "name", "business", "email", "phone", "source", "first_reply", "status"], ["L999", "2026-10-01 09:00", "QA Person", "QA Studio Buyer", "qa@example.test", "214-555-0999", "Referral", "", "New"]),
        "qa-bookings.csv": (["booking_id", "date", "client_name", "email", "service", "status", "price"], ["B999", "10/01/2026", "QA Studio Buyer", "qa@example.test", "Content Day", "completed", "1500"]),
        "qa-invoices.csv": (["invoice_no", "bill_to", "email", "issued", "due", "amount", "status", "memo"], ["INV-9999", "QA Studio Buyer", "qa@example.test", "2026-10-01", "2026-10-02", "1500", "unpaid", "B999 Content Day"]),
        "qa-payments.csv": (["payment_id", "date", "payer", "payer_email", "amount", "method", "reference"], ["P9999", "03/10/2026", "QA Studio Buyer", "qa@example.test", "500", "ACH", "INV-9999"]),
        "qa-board.csv": (["video_id", "client", "title", "editor", "stage", "notes_on_board", "revisions", "editor_hours", "client_approved_on", "shoot_booking"], ["V999", "QA Studio Buyer", "QA original", "Ali", "Delivered", "", "0", "1.0", "", "B999"]),
    }
    for name, (headers, row) in records.items():
        with (folder / name).open("w", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(headers)
            writer.writerow(row)
    (folder / "qa-messages.txt").write_text("[2026-10-04 10:00] EMAIL from qa@example.test: Please make the captions bigger on QA original.\n")
    return [folder / name for name in [*records, "qa-messages.txt"]]


def run(url, port, output_directory=None, novel_request=False):
    global OUT
    if output_directory:
        OUT = Path(output_directory).resolve()
    OUT.mkdir(parents=True, exist_ok=True)
    report = {"run_at": datetime.now(timezone.utc).isoformat(), "url": url, "viewport": {"width": 375, "height": 812}, "checks": [], "issues": []}
    def check(name, condition, details=None):
        report["checks"].append({"name": name, "passed": bool(condition), "details": details})
        print(("PASS " if condition else "FAIL ") + name, flush=True)
        if not condition:
            report["issues"].append(name)
    # Do not start Chromium until the parent's existing preview is healthy.
    try:
        request = urllib.request.Request(url, headers={'User-Agent':'Mozilla/5.0'})
        with urllib.request.urlopen(request, timeout=10) as response:
            report['readiness_probe'] = {'status':response.status,'url':response.url}
            if response.status != 200:
                raise RuntimeError("Preview is not ready")
    except urllib.error.HTTPError as error:
        report['readiness_probe'] = {'status':error.code,'body':error.read(2000).decode(errors='replace')}
        if not url.startswith('https://'):
            (OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n')
            raise
        # The native hosting service has confirmed this deployment ready. Test the
        # actual browser too: anti-bot handling may differ for urllib and Chromium.
    profile = tempfile.TemporaryDirectory(prefix="axeom-browser-qa-", dir="/tmp")
    browser = None
    cdp = None
    log = (OUT / "chromium.log").open("w")
    try:
        browser = subprocess.Popen([shutil.which("chromium") or "chromium", "--headless=new", "--no-sandbox", "--disable-gpu", "--disable-dev-shm-usage", "--no-first-run", "--no-default-browser-check", "--remote-debugging-address=127.0.0.1", f"--remote-debugging-port={port}", "--user-data-dir=" + profile.name, "about:blank"], stdout=log, stderr=log)
        tab = None
        for _ in range(100):
            try:
                tabs = json.load(urllib.request.urlopen(f"http://127.0.0.1:{port}/json/list", timeout=2))
                tab = next(t for t in tabs if t["type"] == "page")
                break
            except (OSError, StopIteration):
                time.sleep(0.1)
        if not tab:
            raise RuntimeError("Chromium CDP did not start")
        cdp = CDP(tab["webSocketDebuggerUrl"])
        cdp.call("Page.enable")
        cdp.call("Runtime.enable")
        cdp.call("DOM.enable")
        cdp.call("Network.enable")
        cdp.call("Emulation.setDeviceMetricsOverride", {"width": 375, "height": 812, "deviceScaleFactor": 1, "mobile": True})
        cdp.call("Emulation.setTouchEmulationEnabled", {"enabled": True})
        cdp.call("Page.navigate", {"url": url})
        cdp.wait("document.querySelector('h1')?.textContent.includes('Start with')")
        initial = cdp.snapshot()
        report["initial"] = initial
        check("Page loads with no login", True)
        check("Mobile page fits viewport", cdp.evaluate("document.documentElement.scrollWidth <= innerWidth"), cdp.evaluate("({scrollWidth:document.documentElement.scrollWidth,innerWidth})"))
        check("Three first decisions visible in DOM", cdp.evaluate("document.querySelectorAll('.priority').length===3"))
        cdp.screenshot("01-today-mobile")
        cdp.call("Emulation.setDeviceMetricsOverride", {"width": 1440, "height": 1000, "deviceScaleFactor": 1, "mobile": False})
        cdp.screenshot("01-today-desktop")
        cdp.call("Emulation.setDeviceMetricsOverride", {"width": 375, "height": 812, "deviceScaleFactor": 1, "mobile": True})
        expected = {"money": "Know where", "requests": "Keep the", "clients": "One client", "opportunities": "Follow the", "files": "Fresh files"}
        for page, title in expected.items():
            cdp.navigate(page)
            check("Navigation: " + page, cdp.wait(f"document.querySelector('h1')?.textContent.includes({json.dumps(title)})"))
            check("Mobile width: " + page, cdp.evaluate("document.documentElement.scrollWidth <= innerWidth"))
            cdp.screenshot("02-" + page + "-mobile")

        # These assertions inspect real recorded results fetched from the app.
        # No successful Jev fixture is generated or substituted by this test.
        initial_jev = cdp.jev_snapshot()
        report["jev_initial"] = initial_jev
        check("Actual Jev archive has validated current predictions", initial_jev["available"] and initial_jev["stats"]["matched"] > 0 and initial_jev["stats"]["rejected"] == 0 and initial_jev["stats"]["matched"] == initial_jev["archive_successes"], initial_jev["stats"])
        check("Actual Jev provenance and review-only flags are retained", initial_jev["provider"].startswith("OpenCode") and "jev" in initial_jev["provider"].lower() and "jev" in initial_jev["requested_model"].lower() and all("jev" in model.lower() for model in initial_jev["models"]) and initial_jev["all_review_only"], {"provider": initial_jev["provider"], "requested_model": initial_jev["requested_model"], "models": initial_jev["models"]})
        cdp.navigate("requests")
        cdp.click("[data-requests='jev']")
        cdp.wait("document.querySelector('h1')?.textContent.includes('Jev message triage')")
        check("Jev tab lists every current recorded suggestion", cdp.evaluate("document.querySelectorAll('#main tbody tr').length") == initial_jev["stats"]["matched"])
        check("Jev tab fits the mobile viewport", cdp.evaluate("document.documentElement.scrollWidth <= innerWidth"))
        first = initial_jev["first"]
        cdp.evaluate("document.querySelector('#main tbody tr details').open=true")
        source_visible = cdp.evaluate("document.querySelector('#main tbody tr').innerText")
        expected_probability = f"{first['route_probability'] * 100:.1f}%"
        check("Jev suggestion displays exact source and native probabilities", first["raw_message"] in source_visible and expected_probability in source_visible and "Edit request:" in source_visible and "Contract risk:" in source_visible)
        before_review = cdp.snapshot()
        cdp.click("[data-jev-review]")
        cdp.wait("document.querySelector('#dialog').open")
        during_review = cdp.snapshot()
        check("Jev review opens owner approval without creating a task", len(during_review["tasks"]) == len(before_review["tasks"]) and cdp.evaluate("!!document.querySelector('#approve-task,#approve-handoff')"))
        cdp.click("#dialog-body [data-cancel]")
        review_cancelled = cdp.snapshot()
        check("Canceling Jev review changes neither tasks nor board gaps", review_cancelled["tasks"] == before_review["tasks"] and review_cancelled["missing"] == before_review["missing"])
        cdp.screenshot("02-jev-triage-mobile")

        paths = fixtures(OUT / "fixtures")
        cdp.upload(paths)
        check("Import waits for approval", cdp.snapshot()["clients"] == initial["clients"])
        check("Six valid unseen files staged", cdp.evaluate("document.querySelectorAll('#dialog-body tbody tr').length===6"))
        cdp.screenshot("03-import-review-mobile")
        cdp.click("#dialog-body [data-cancel]")
        check("Cancel leaves records unchanged", cdp.snapshot()["clients"] == initial["clients"])

        cdp.upload(paths)
        cdp.click("#approve-import")
        cdp.wait("!document.querySelector('#dialog').open")
        after = cdp.snapshot()
        report["after_new_import"] = after
        check("New client linked automatically", after["clients"] == initial["clients"] + 1 and after["qaClient"] is not None)
        check("New invoice less partial bank payment updates overdue", after["overdue"] == initial["overdue"] + 1000, {"before": initial["overdue"], "after": after["overdue"]})
        check("New request enters missing queue", after["missing"] == initial["missing"] + 1, {"before": initial["missing"], "after": after["missing"]})
        check("New lead enters unanswered queue", after["waiting"] == initial["waiting"] + 1)
        check("New linked booking is billed", after["unbilled"] == initial["unbilled"])
        check("Dates use bank DD/MM and challenge snapshot", after["qaInvoice"] and after["qaInvoice"]["days_late"] == 4)
        after_jev = cdp.jev_snapshot()
        report["jev_after_new_message"] = after_jev
        check("Unseen upload lowers Jev coverage instead of fabricating a prediction", after_jev["stats"]["matched"] == initial_jev["stats"]["matched"] and after_jev["stats"]["missing"] == initial_jev["stats"]["missing"] + 1, {"before": initial_jev["stats"], "after": after_jev["stats"]})
        cdp.navigate("requests")
        cdp.click("[data-requests='jev']")
        check("Newly uncovered message count is visible in Jev tab", cdp.evaluate("document.querySelector('#main').innerText").find(f"{after_jev['stats']['missing']} need a fresh Jev run") >= 0)

        cdp.upload(paths)
        preview_rows = cdp.evaluate("Array.from(document.querySelectorAll('#dialog-body tbody tr')).map(tr=>Array.from(tr.cells).slice(1).map(td=>Number(td.textContent)))")
        check("Duplicate file preview shows no additions or changes", all(pair == [0, 0] for pair in preview_rows), preview_rows)
        cdp.click("#approve-import")
        cdp.wait("!document.querySelector('#dialog').open")
        duplicated = cdp.snapshot()
        check("Duplicate upload does not double-count", all(duplicated[key] == after[key] for key in ("clients", "overdue", "unbilled", "missing", "waiting", "payments", "invoices", "bookings", "videos")))

        cdp.navigate("clients")
        cdp.click("[data-client='QA Studio Buyer']")
        detail = cdp.evaluate("document.querySelector('#main').innerText")
        check("Client profile connects all six source kinds", all(term in detail for term in ("Bookings · 1", "Invoices · 1", "Bank receipts · 1", "Videos · 1", "Lead & contact history · 1", "Original messages · 1")))
        cdp.screenshot("04-new-client-mobile")

        cdp.navigate("requests")
        cdp.click("[data-requests='missing']")
        cdp.evaluate("document.querySelector('#search').value='QA Studio Buyer';document.querySelector('#search').dispatchEvent(new Event('input',{bubbles:true}))")
        check("Request search finds new source", cdp.evaluate("document.querySelectorAll('.request-card').length===1"))
        cdp.click("[data-capture]")
        cdp.click("#approve-handoff")
        cdp.wait("!document.querySelector('#dialog').open")
        captured = cdp.snapshot()
        check("Approved handoff removes missing instruction", captured["missing"] == initial["missing"], {"before": after["missing"], "after": captured["missing"]})
        check("Approved handoff creates assigned task and board note", captured["qaVideo"] and captured["qaVideo"]["notes_on_board"] == "Captions bigger" and captured["qaVideo"]["stage"] == "In revision" and len(captured["tasks"]) == 1)

        cdp.navigate("today")
        cdp.click("[data-task]")
        done = cdp.snapshot()
        check("Task checkbox completes saved task", done["tasks"][0]["done"] is True)

        # An update replaces one bank row instead of adding a second receipt.
        payment_path = OUT / "fixtures" / "qa-payments.csv"
        payment_path.write_text(payment_path.read_text().replace(",500,ACH,", ",1500,ACH,"))
        cdp.upload([payment_path])
        cdp.click("#approve-import")
        cdp.wait("!document.querySelector('#dialog').open")
        paid = cdp.snapshot()
        check("Changed payment upserts and clears new overdue", paid["payments"] == after["payments"] and paid["overdue"] == initial["overdue"])

        # One malformed file rejects the full batch, including an otherwise valid new lead.
        malformed = OUT / "fixtures" / "qa-invalid.csv"
        malformed.write_text("invoice_no,bill_to,email,issued,due,amount,status,memo\nINV-9998,QA Studio Buyer,qa@example.test,2026-10-01,2026-10-02,notmoney,unpaid,\n")
        extra_lead = OUT / "fixtures" / "qa-extra-lead.csv"
        extra_lead.write_text((OUT / "fixtures" / "qa-leads.csv").read_text().replace("L999,", "L998,"))
        cdp.upload([extra_lead, malformed])
        check("Malformed batch shows a useful error", cdp.evaluate("document.querySelector('#dialog-body').innerText.includes('invalid amount')"))
        rejected = cdp.snapshot()
        check("Malformed batch is atomic", rejected["leads"] == paid["leads"] and rejected["invoices"] == paid["invoices"])
        cdp.click("#dialog-body [data-cancel]")

        cdp.call("Page.reload", {"ignoreCache": True})
        cdp.wait("document.querySelector('h1')?.textContent.includes('Start with')")
        reloaded = cdp.snapshot()
        check("Imports and handoffs survive reload", all(reloaded[k] == paid[k] for k in ("clients", "overdue", "unbilled", "missing", "waiting", "payments", "invoices", "bookings", "videos", "tasks")))
        cdp.screenshot("05-after-reload-mobile")

        if novel_request:
            novel_file = OUT / 'fixtures' / 'qa-novel-request.txt'
            novel_file.write_text('[2026-10-05 12:00] EMAIL from qa@example.test: Please replace the opening logo on V999 with the supplied updated logo.\n')
            cdp.upload([novel_file])
            cdp.click('#approve-import')
            cdp.wait("!document.querySelector('#dialog').open")
            novel_before = cdp.snapshot()
            check('Novel edit is visible for owner review', novel_before['ambiguous'] == reloaded['ambiguous'] + 1)
            cdp.navigate('requests')
            cdp.click("[data-requests='review']")
            cdp.evaluate("document.querySelector('#search').value='QA Studio Buyer';document.querySelector('#search').dispatchEvent(new Event('input',{bubbles:true}))")
            cdp.click('[data-capture]')
            cdp.evaluate("document.querySelector('#handoff-video').value='V999'")
            cdp.click('#approve-handoff')
            cdp.wait("!document.querySelector('#dialog').open")
            novel_after = cdp.snapshot()
            check('Owner-approved novel edit leaves ambiguous queue', novel_after['ambiguous'] == reloaded['ambiguous'])
            check('Owner-approved novel edit retains explicit mapping', len(novel_after['requestLinks']) == len(reloaded['requestLinks']) + 1 and 'opening logo' in novel_after['qaVideo']['notes_on_board'])
            cdp.call('Page.reload', {'ignoreCache':True})
            cdp.wait("document.querySelector('h1')?.textContent.includes('Keep the')")
            novel_reload = cdp.snapshot()
            check('Novel edit mapping survives reload', novel_reload['ambiguous'] == novel_after['ambiguous'] and novel_reload['requestLinks'] == novel_after['requestLinks'])
            report['novel_request_after_reload'] = novel_reload

        cdp.navigate("files")
        current_jev = cdp.jev_snapshot()
        evaluation = current_jev["evaluation"]
        jev_text = cdp.evaluate("document.querySelector('#main').innerText")
        evaluation_count = f"{evaluation['evaluated_messages']}/{evaluation['labeled_messages']} reference cases evaluated"
        measured_route = evaluation.get("accuracy_by_field", {}).get("route") if evaluation.get("accuracy_by_field") else None
        check("Actual Jev measurements and benchmark scope are visible", evaluation["evaluated_messages"] > 0 and evaluation["labeled_messages"] == 40 and evaluation_count in jev_text and measured_route is not None and f"{measured_route * 100:.1f}%" in jev_text and "Selected development benchmark: 40 messages, including 3 risk-positive examples" in jev_text and "probability" not in evaluation_count, evaluation)
        check("Jev panel distinguishes recorded inference from file imports", "OpenCode's explicitly free Jev model" in jev_text and "Importing files makes no API call and sends no messages" in jev_text and "0 / 40 examples evaluated" not in jev_text)

        # Negative-only synthetic fixture: deliberately invalid metadata and no
        # predictions. This file is never represented as a successful model run.
        invalid_jev = OUT / "fixtures" / "qa-invalid-jev.json"
        invalid_jev.write_text(json.dumps({"provider": "SYNTHETIC INVALID QA FIXTURE", "requested_model": "not-a-model", "predictions": []}) + "\n")
        storage_before_invalid = cdp.evaluate("localStorage.getItem('axeom169-desk-v1')")
        cdp.upload([invalid_jev], selector="#jev-input", wait_dialog=False)
        cdp.wait("document.querySelector('#toast').textContent.includes('Jev import rejected:')")
        check("Invalid Jev result JSON is rejected without a success preview", not cdp.evaluate("document.querySelector('#dialog').open") and cdp.evaluate("document.querySelector('#toast').textContent.includes('Jev import rejected:')"))
        check("Invalid Jev result JSON cannot alter browser state", cdp.evaluate("localStorage.getItem('axeom169-desk-v1')") == storage_before_invalid)

        # Exercise import with the actual archived API output, never a synthetic
        # success. A local copy of this very asset is included with the submission.
        actual_results_file = ROOT / "axeom-desk" / "dist" / "jev-results.json"
        if not actual_results_file.exists():
            raise RuntimeError("Actual Jev result archive is missing; do not substitute test predictions")
        tasks_before_result_import = cdp.snapshot()["tasks"]
        cdp.upload([actual_results_file], selector="#jev-input")
        check("Actual Jev result import waits for owner approval", cdp.evaluate("!!document.querySelector('#approve-jev')") and cdp.snapshot()["tasks"] == tasks_before_result_import)
        cdp.click("#dialog-body [data-cancel]")
        check("Canceling actual Jev result import leaves state unchanged", cdp.evaluate("localStorage.getItem('axeom169-desk-v1')") == storage_before_invalid)
        cdp.upload([actual_results_file], selector="#jev-input")
        cdp.click("#approve-jev")
        cdp.wait("!document.querySelector('#dialog').open")
        imported_jev = cdp.jev_snapshot()
        check("Approved actual Jev JSON import retains only current suggestions and no tasks", imported_jev["stored_results"] and imported_jev["stats"]["matched"] == current_jev["stats"]["matched"] and imported_jev["stats"]["rejected"] == 0 and cdp.snapshot()["tasks"] == tasks_before_result_import, imported_jev["stats"])
        cdp.call("Page.reload", {"ignoreCache": True})
        cdp.wait("document.querySelector('h1')?.textContent.includes('Fresh files')")
        reloaded_jev = cdp.jev_snapshot()
        check("Approved recorded Jev results survive reload", reloaded_jev["stored_results"] and reloaded_jev["stats"]["matched"] == imported_jev["stats"]["matched"] and reloaded_jev["stats"]["missing"] == imported_jev["stats"]["missing"])
        cdp.screenshot("06-jev-measurements-mobile")
        report["jev_final"] = reloaded_jev
        check("No uncaught JavaScript errors", not cdp.errors, cdp.errors)
        required_assets = ('style.css','app.mjs','engine.mjs','finance.mjs','marketing.mjs','seed.json','identities.json','request-audit.json')
        check('All eight runtime assets returned HTTP 200', all(any(r['url'].split('?')[0].endswith('/'+asset) and r['status']==200 for r in cdp.responses) for asset in required_assets))
        jev_assets = ('jev-results.mjs','jev-results.json','jev/evaluation.json')
        check('Actual Jev mapper, results and evaluation assets returned HTTP 200', all(any(r['url'].split('?')[0].endswith('/'+asset) and r['status']==200 for r in cdp.responses) for asset in jev_assets))
        check('Reviewing and importing Jev output makes no inference API request', not any('api.typesafe.ai' in r['url'] or '/systemone' in r['url'] or 'opencode.ai/zen' in r['url'] for r in cdp.responses))
        report['network_responses'] = cdp.responses
        report["final"] = reloaded
        report["runtime_errors"] = cdp.errors
        report["passed"] = all(item["passed"] for item in report["checks"])
    except Exception as error:
        report["fatal_error"] = str(error)
        report["passed"] = False
        print("FATAL " + str(error), flush=True)
        if cdp:
            try:
                cdp.screenshot("99-failure-mobile")
            except Exception:
                pass
    finally:
        (OUT / "report.json").write_text(json.dumps(report, indent=2) + "\n")
        if cdp:
            cdp.ws.close()
        if browser:
            browser.terminate()
            try:
                browser.wait(timeout=8)
            except subprocess.TimeoutExpired:
                browser.kill()
                browser.wait(timeout=5)
        log.close()
        try:
            profile.cleanup()
        except OSError:
            pass
    return report["passed"]


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--url", default="http://127.0.0.1:8765/")
    parser.add_argument("--cdp-port", type=int, default=9222)
    parser.add_argument("--out", type=Path)
    parser.add_argument("--novel-request", action='store_true')
    args = parser.parse_args()
    raise SystemExit(0 if run(args.url, args.cdp_port, args.out, args.novel_request) else 1)
