import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {build,importFiles,parseMessages,TABLES} from '../axeom-desk/dist/engine.mjs';
import {marketing} from '../axeom-desk/dist/marketing.mjs';

const readJSON=async path=>JSON.parse(await readFile(new URL(path,import.meta.url),'utf8'));
const seed=await readJSON('../axeom-desk/dist/seed.json');
const reviewed=await readJSON('../axeom-desk/dist/identities.json');
const audit=await readJSON('../analysis/requests/request_labels.json');
const expected=await readJSON('../analysis/finance/result.json');
const model=data=>build(data,reviewed,audit);
const csv=(type,rows)=>[TABLES[type],...rows.map(row=>TABLES[type].map(k=>row[k]??''))].map(row=>row.map(v=>'"'+String(v).replaceAll('"','""')+'"').join(',')).join('\r\n');
const rawFiles=await Promise.all([...Object.keys(TABLES).map(async type=>({name:type+'.csv',text:await readFile(new URL('../data/'+type+'.csv',import.meta.url),'utf8')})),(async()=>({name:'messages.txt',text:await readFile(new URL('../data/messages.txt',import.meta.url),'utf8')}))()]);

test('actual app identity graph retains 30 clients and Northstar payer without absorbing recipients',()=>{
  const x=model(seed);
  assert.equal(x.entities.filter(e=>!e.payer_only).length,30);
  assert.equal(x.resolve('','angela@northstarmktg.com'),'Northstar Media Co');
  assert.equal(x.resolve('Northstar - Meridian','angela@northstarmktg.com'),'Meridian Physical Therapy');
  assert.equal(x.resolve('Sunset Pediatrics','angela@northstarmktg.com'),'Sunset Pediatrics');
  for(const client of ['Sunset Pediatrics','Meridian Physical Therapy'])assert.equal(x.entities.find(e=>e.name===client).emails.includes('angela@northstarmktg.com'),false);
  assert.equal(x.resolve('Oak Cliff Realty LLC','joy@oakcliffrealty.com'),'Oak Cliff Realty LLC');
  assert.equal(x.resolve('Oakcliff RG','raj@oakcliffrg.com'),'Oakcliff Realty Group');
});

test('actual build reproduces independently audited finance and preserves disputed cancellation',()=>{
  const {finance:f}=model(seed);
  assert.deepEqual(f.overdue,expected.overdue);
  assert.equal(f.overdue_total,11050);
  assert.deepEqual(f.never_billed,expected.never_billed);
  assert.equal(f.never_billed_total,2040);
  assert.equal(f.credits.reduce((s,r)=>s+r.amount,0),900);
  assert.equal(f.wrong.length,6);
  assert.equal(f.disputed.find(d=>d.invoice==='INV-1135').amount,1500);
  assert.equal(f.overdue.some(i=>i.invoice==='INV-1135'),false);
  assert.equal(f.invoices.find(i=>i.invoice_no==='INV-1150').balance,0);
  assert.equal(f.issues.filter(i=>i.type==='unmatched_invoice').length,0);
  assert.ok(f.issues.some(i=>i.type==='ambiguous_booking_allocation'));
});

test('every cent conserves across the actual app reconciliation',()=>{
  const f=model(seed).finance,nonvoid=f.invoices.filter(i=>i.status!=='void');
  const invoiceCents=nonvoid.reduce((s,i)=>s+i.amount_cents,0);
  const bankCents=f.payments.reduce((s,p)=>s+p.amount_cents,0);
  const balanceCents=nonvoid.reduce((s,i)=>s+i.balance_cents,0);
  const receiptRemainder=f.payments.reduce((s,p)=>s+p.remaining_cents,0);
  assert.equal(invoiceCents,15281000);assert.equal(bankCents,12649000);
  assert.equal(balanceCents,2722000);assert.equal(receiptRemainder,90000);
  assert.equal(invoiceCents-bankCents+receiptRemainder,balanceCents);
  assert.equal(f.payments.reduce((s,p)=>s+p.allocations.reduce((n,a)=>n+Math.round(a.amount*100),0),0),bankCents-receiptRemainder);
  assert(f.invoices.every(i=>i.balance_cents>=0));
  assert(f.payments.every(p=>p.remaining_cents>=0));
});

test('marketing over the actual model agrees with independent Python contribution audit',()=>{
  const actual=marketing(seed,model(seed));
  for(const exp of expected.channels){
    const c=actual.channels.find(c=>c.channel===exp.channel);assert.ok(c);
    for(const key of ['clients','earned_revenue','studio_cost','editing_cost','contribution','contribution_per_client'])assert.equal(c[key],exp[key],exp.channel+' '+key);
    assert.equal(c.incomplete,false);
  }
  assert.equal(actual.channels[0].channel,'Meta ad');assert.equal(actual.channels[0].contribution,24000.4);
  assert.equal(actual.clients.find(c=>c.client==='Tran Dental').channel,'Meta ad');
  assert.equal(actual.clients.find(c=>c.client==='Evergreen Athletics').channel,'LinkedIn');
  assert.equal(actual.clients.some(c=>c.client==='Northstar Media Co'),false);
});

test('all eight original files import twice without duplicate money, messages or services',()=>{
  const original=JSON.stringify(seed);
  const first=importFiles(seed,rawFiles),second=importFiles(first.data,rawFiles);
  for(const result of [first,second]){
    assert.equal(result.report.length,8);
    for(const r of result.report){assert.equal(r.added,0,r.file);assert.equal(r.updated,0,r.file);}
    for(const type of Object.keys(TABLES))assert.equal(result.data[type].length,seed[type].length,type);
    assert.equal(parseMessages(result.data.messages).length,194);
    const x=model(result.data);assert.equal(x.finance.overdue_total,11050);assert.equal(x.finance.never_billed_total,2040);assert.equal(x.lost.length,model(seed).lost.length);assert.equal(x.lost.filter(r=>!r.scopeChange).length,44);
  }
  assert.equal(JSON.stringify(seed),original,'Import must not mutate the source snapshot');
});

const newRows={
  leads:[{lead_id:'L990',created:'2026-10-05 08:00',name:'Inez Cole',business:'Cobalt Dental',email:'inez@cobaltdental.example',phone:'214-555-0990',source:'Referral',first_reply:'2026-10-05',status:'Won'}],
  bookings:[{booking_id:'B990',date:'10/05/2026',client_name:'Cobalt Dental',email:'inez@cobaltdental.example',service:'Reels Pack',status:'completed',price:'$900'}],
  invoices:[{invoice_no:'INV-9990',bill_to:'Inez Cole',email:'inez@cobaltdental.example',issued:'2026-10-05',due:'2026-10-05',amount:'900.00',status:'unpaid',memo:'B990 Reels Pack'}],
  payments:[{payment_id:'P9990',date:'06/10/2026',payer:'Cobalt Dental LLC',payer_email:'inez@cobaltdental.example',amount:'400',method:'ACH',reference:'INV-9990'}],
  production_board:[{video_id:'V990',client:'Cobalt Dental',title:'Meet Inez',editor:'Remy',stage:'In edit',notes_on_board:'',revisions:'0',editor_hours:'2.5',client_approved_on:'',shoot_booking:'B990'}]
};
const newFiles=Object.entries(newRows).map(([type,rows])=>({name:'new-'+type+'.csv',text:csv(type,rows)}));

test('unseen client, lead, work, invoice and bank upload link automatically and update money/marketing',()=>{
  const imported=importFiles(seed,newFiles),x=model(imported.data),f=x.finance;
  assert.equal(x.entities.filter(e=>!e.payer_only).length,31);
  assert.equal(x.resolve('Inez Cole','inez@cobaltdental.example'),'Cobalt Dental');
  assert.equal(x.board.find(v=>v.video_id==='V990').canonical,'Cobalt Dental');
  assert.equal(f.invoices.find(i=>i.invoice_no==='INV-9990').balance,500);
  assert.equal(f.overdue.find(i=>i.invoice==='INV-9990').days_late,1);
  assert.equal(f.overdue_total,11550);assert.equal(f.never_billed_total,2040);
  assert.equal(f.payments.find(p=>p.payment_id==='P9990').allocations[0].invoice,'INV-9990');
  const client=marketing(imported.data,x).clients.find(c=>c.client==='Cobalt Dental');
  assert.equal(client.channel,'Referral');assert.equal(client.contribution,680);
  const repeated=importFiles(imported.data,newFiles);
  assert(repeated.report.every(r=>r.added===0&&r.updated===0));
  assert.equal(model(repeated.data).finance.overdue_total,11550);
});

test('an invalid later file rolls back an otherwise valid import batch',()=>{
  const original=JSON.stringify(seed);
  const invalid=csv('invoices',[{...newRows.invoices[0],amount:'not money'}]);
  assert.throws(()=>importFiles(seed,[newFiles[0],{name:'bad-invoices.csv',text:invalid}]),/invalid amount/);
  assert.equal(JSON.stringify(seed),original);
  assert.equal(model(seed).entities.filter(e=>!e.payer_only).length,30);
});

test('HTML payload remains inert model data; this is not a browser DOM execution test',()=>{
  const payload='<img src=x onerror="globalThis.__axeomInjected=1">';
  delete globalThis.__axeomInjected;
  const rows=[{...newRows.bookings[0],booking_id:'B991',client_name:payload,email:'payload@example.invalid'}];
  const imported=importFiles(seed,[{name:'bookings.csv',text:csv('bookings',rows)}]);
  const x=model(imported.data);
  assert.equal(x.finance.bookings.find(b=>b.booking_id==='B991').client,payload);
  assert.equal(globalThis.__axeomInjected,undefined);
  assert.equal(imported.data.bookings.find(b=>b.booking_id==='B991').client_name,payload);
});

test('uploaded cost and team rate changes recompute contribution rather than use fixed totals',()=>{
  const changedCosts=seed.costs.map(r=>/studio time/i.test(r.item)?{...r,cost:'$80/hour'}:r);
  const costData=importFiles(seed,[{name:'costs.csv',text:csv('costs',changedCosts)}]).data;
  const doubled=marketing(costData,model(costData)).channels.find(c=>c.channel==='Meta ad');
  assert.equal(doubled.studio_cost,11520);assert.equal(doubled.contribution,18240.4);
  let data=importFiles(seed,newFiles).data;
  const changedTeam=seed.team.map(t=>t.name==='Remy'?{...t,pay:'$80/hour'}:t);
  data=importFiles(data,[{name:'team.csv',text:csv('team',changedTeam)}]).data;
  assert.equal(marketing(data,model(data)).clients.find(c=>c.client==='Cobalt Dental').contribution,580);
});
