# Verification evidence

The baseline is the original pack as of October 6, 2026, not the execution date. Tests use temporary data/browser state; source CSVs are preserved.

- `integration.test.mjs` — 9 checks over the actual app graph, finance and marketing: independent-result parity, every-cent conservation, all eight files uploaded twice, unseen entities, changed cost rates, and atomic import rejection.
- `request-engine.test.mjs` — 12 checks: all 118 audited mappings, dynamic notes, exact video IDs, repeated-title review, novel edit handling, Spanish/voice messages, future cutoff and identity separation.
- `../analysis/finance/test-engine.mjs` — baseline and financial edge cases: partial/new payments, new services, malformed money, unknown-reference quarantine, future records, distant services and unrelated payers.
- `../integration/jev/test_jev.py` — 15 offline harness checks. These validate the client; actual live metrics are separately recorded in integration/jev/evaluation.json.
- `browser/report.json` and screenshots — 35 actual Chromium checks at 375×812: navigation, viewport fit, approval/cancel, six unseen uploads, duplicate prevention, full client history, request handoff/task completion, payment upsert, batch rejection and reload persistence. No uncaught JavaScript errors observed.
- `published/` — 40 passing fresh-profile checks of the actual hosted app, including the novel-request owner-confirmed mapping and a desktop screenshot. A local server check is never labeled an anonymous production check. Eight runtime assets returned200 and no uncaught JS errors were observed.
- `submission_check.py` — structural handoff/ZIP consistency and honest pending-requirement report.

Chromium emulation does not prove physical-device behavior, accessibility conformance, human comprehension within ten seconds, or performance on every unseen data arrangement. The source-linked audit preserves the evidence and assumptions used for each finding.

`make_writeup_pdf.py` typeset `writeup.pdf` locally and verified two pages plus end-to-end content markers. The optional browser-print attempt was aborted during its approval wait and was not used.

New Jev integration:12 extra pure mapper tests validate exact-source matching, native-answer consistency, stale/missing results, duplicate rejection and review-only behavior. The source snapshot contains192real free-model results; the frozen40-case benchmark remains separate. New phone checks are retained in jev-browser/.

After the documentation refresh, the two historical triage screenshots with superseded wording were omitted. The historical reports retain their original timestamps and measured outcomes. Fresh interface checks and screenshots are retained in `current/`; the interface states the benchmark's sample size and scope.
