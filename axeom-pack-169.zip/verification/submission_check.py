"""Validate the handoff without mistaking pending personal/Jev requirements for completion."""
from pathlib import Path
from zipfile import ZipFile
import json
from pypdf import PdfReader

root=Path(__file__).resolve().parents[1]
a=json.loads((root/'answers.json').read_text())
assert a['pack_id']==169
assert a['client_count']==len(a['clients'])==30
assert len({c['name'] for c in a['clients']})==30
assert sum(r['amount_owed'] for r in a['overdue'])==a['overdue_total']==11050
assert sum(r['amount'] for r in a['never_billed'])==a['never_billed_total']==2040
assert sum(r['amount'] for r in a['we_owe'])==900
assert len(a['lost_requests'])==44 and len(a['never_replied_leads'])==23
assert a['audit_context']['as_of']=='2026-10-06'
assert a['live_link'].startswith('https://')
for name in ['writeup.md','assumptions.md','daily_log.md','ai_log.md','recording_guide.md','video_transcript.md']:
    assert (root/name).stat().st_size>0,name
pages=None
if (root/'writeup.pdf').exists():
    pages=len(PdfReader(root/'writeup.pdf').pages)
    assert 0<pages<=2
zip_path=root/'submission/axeom-pack-169.zip'
if zip_path.exists():
    with ZipFile(zip_path) as z:
        assert z.testzip() is None
        assert json.loads(z.read('answers.json'))==a,'Regenerate ZIP after changing answers'
        assert not any('/.git/' in p or '/__pycache__/' in p or Path(p).name.startswith('.env') for p in z.namelist())
pending=[]
if 'HERE' in a['your_name'] or 'HERE' in a['your_email']:pending.append('Replace applicant identity placeholders')
if not a['video_link']:pending.append('Record video, add URL and actual transcript')
if not json.loads((root/'integration/jev/evaluation.json').read_text()).get('evaluated_messages'):pending.append('Run authenticated Jev with verified free credits; review labels and measure accuracy')
print(json.dumps({'structural_checks':'passed','writeup_pdf_pages':pages,'pending_requirements':pending},indent=2))
