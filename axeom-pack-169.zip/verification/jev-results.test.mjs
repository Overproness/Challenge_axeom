/** ALL RESPONSE OBJECTS IN THIS FILE ARE SYNTHETIC UNIT-TEST FIXTURES.
 * They are not API results, are never saved as predictions, and do not measure Jev.
 */
import test from 'node:test';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {readFile} from 'node:fs/promises';
import {JEV_ROUTES,jevMessageId,triageForMessages} from '../axeom-desk/dist/jev-results.mjs';

const RAW='[2026-10-06 08:00] EMAIL from synthetic@example.invalid: SYNTHETIC TEST: Please make captions bigger.';
const hash=raw=>createHash('sha256').update(raw).digest('hex').slice(0,16);
function syntheticPrediction(raw=RAW,route='revision') {
  const probabilities=Object.fromEntries(JEV_ROUTES.map(k=>[k,k===route?0.91:0.01]));
  return {status:'succeeded',message_id:hash(raw),raw_message:raw,
    response:{model:'jev-1.13-free',answers:{route:{type:'choice',choice:route,probabilities},needs_revision:{type:'noul',noul:0.8},continuation_risk:{type:'noul',noul:0.1}}},
    result:{route,route_probability:0.91,needs_revision_probability:0.8,needs_revision:true,continuation_risk_probability:0.1,continuation_risk:false,review_reason:'SYNTHETIC TEST: owner review required',action_authorized:false}};
}
const syntheticEnvelope=predictions=>({provider:'OpenCode Jev — SYNTHETIC UNIT TEST, NOT API OUTPUT',requested_model:'jev-1.13-free',predictions});
const data=messages=>({messages});

test('message hashing agrees with independent Node crypto, including every reference raw message',async()=>{
  const references=JSON.parse(await readFile(new URL('../integration/jev/reference_labels.json',import.meta.url),'utf8'));
  for(const label of references){assert.equal(jevMessageId(label.raw_message),hash(label.raw_message));assert.equal(jevMessageId(label.raw_message),label.message_id);}
  for(const raw of ['',RAW,'¿Una canción más tranquila?','a'.repeat(10000)])assert.equal(jevMessageId(raw),hash(raw));
});

test('a valid synthetic recorded response becomes a source-linked review suggestion only',()=>{
  const input=data(RAW),envelope=syntheticEnvelope([syntheticPrediction()]);
  const before=JSON.stringify({input,envelope});
  const result=triageForMessages(input,envelope);
  assert.equal(result.stats.matched,1);assert.equal(result.stats.missing,0);
  assert.equal(result.suggestions[0].raw_message,RAW);assert.equal(result.suggestions[0].source_line,1);
  assert.equal(result.suggestions[0].review_required,true);assert.equal(result.suggestions[0].action_authorized,false);
  assert.equal(result.suggestions[0].response,undefined);
  assert.equal(JSON.stringify({input,envelope}),before,'pure mapper must not mutate its inputs');
});

test('failed, missing and unknown-status predictions never increase matched results',()=>{
  const failed={status:'failed',message_id:hash(RAW),raw_message:RAW,error:'SYNTHETIC failure'};
  const result=triageForMessages(data(RAW),syntheticEnvelope([failed,{raw_message:RAW},{status:'pending'}]));
  assert.equal(result.stats.matched,0);assert.equal(result.stats.failed,1);assert.equal(result.stats.rejected,2);assert.equal(result.stats.missing,1);
  assert.equal(result.accuracy,undefined);assert.equal(result.stats.accuracy,undefined);
});

test('absent envelopes are unavailable and invalid metadata is rejected',()=>{
  assert.equal(triageForMessages(data(RAW),null).available,false);
  for(const bad of [{},syntheticEnvelope({}),{...syntheticEnvelope([]),requested_model:'different-model'}, {...syntheticEnvelope([]),provider:''}, {...syntheticEnvelope([]),provider:'Unknown provider'}]) {
    const result=triageForMessages(data(RAW),bad);assert.equal(result.available,false);assert.equal(result.stats.matched,0);assert.ok(result.error);
  }
});

test('a successful but unknown route or malformed probabilities is rejected',()=>{
  const cases=[
    p=>{p.response.answers.route.choice='unknown';p.result.route='unknown';},
    p=>{delete p.response.answers.route.probabilities.other;},
    p=>{p.response.answers.route.probabilities.spam=NaN;},
    p=>{p.response.answers.route.probabilities.spam=1.1;},
    p=>{p.response.answers.route.probabilities.spam=true;},
    p=>{p.response.answers.route.probabilities.other=0.9;},
    p=>{p.response.model='not-a-jev-model';}
  ];
  for(const mutate of cases){const p=syntheticPrediction();mutate(p);const result=triageForMessages(data(RAW),syntheticEnvelope([p]));assert.equal(result.stats.matched,0);assert.equal(result.stats.rejected,1);}
});

test('typed answers and derived flags/probabilities must agree and authorize no action',()=>{
  const cases=[
    p=>{p.result.route_probability=0.2;},
    p=>{p.result.needs_revision=false;},
    p=>{p.result.needs_revision_probability=0.7;},
    p=>{p.response.answers.continuation_risk.noul=-0.1;},
    p=>{p.response.answers.needs_revision.type='choice';},
    p=>{p.result.continuation_risk='false';},
    p=>{p.result.action_authorized=true;},
    p=>{delete p.result.action_authorized;},
    p=>{p.result.review_reason='';}
  ];
  for(const mutate of cases){const p=syntheticPrediction();mutate(p);const result=triageForMessages(data(RAW),syntheticEnvelope([p]));assert.equal(result.stats.matched,0);assert.equal(result.stats.rejected,1);}
});

test('unknown current text is outdated, and a mismatched identifier is rejected',()=>{
  const missing=triageForMessages(data(RAW.replace('bigger','larger')),syntheticEnvelope([syntheticPrediction()]));
  assert.equal(missing.stats.outdated,1);assert.equal(missing.stats.matched,0);assert.equal(missing.stats.missing,1);
  const tampered=syntheticPrediction();tampered.message_id='0000000000000000';
  const result=triageForMessages(data(RAW),syntheticEnvelope([tampered]));assert.equal(result.stats.rejected,1);assert.equal(result.stats.matched,0);
});

test('identical raw duplicates collapse, including reordered derived-result fields',()=>{
  const a=syntheticPrediction(),b=syntheticPrediction();b.result=Object.fromEntries(Object.entries(b.result).reverse());
  const result=triageForMessages(data(RAW+'\n'+RAW),syntheticEnvelope([a,b]));
  assert.equal(result.stats.current_messages,1);assert.equal(result.stats.matched,1);assert.equal(result.stats.duplicates,1);assert.equal(result.stats.conflicts,0);
});

test('conflicting duplicate classifications are removed and require review of the run',()=>{
  const result=triageForMessages(data(RAW),syntheticEnvelope([syntheticPrediction(),syntheticPrediction(RAW,'churn')]));
  assert.equal(result.stats.matched,0);assert.equal(result.stats.duplicates,1);assert.equal(result.stats.conflicts,1);assert.equal(result.stats.rejected,2);assert.equal(result.stats.missing,1);
});

test('new uploaded messages can match results but unprocessed messages remain missing',()=>{
  const fresh='[2026-10-06 08:01] WHATSAPP from +1 214-555-0199 (Synthetic): SYNTHETIC TEST: Can we change music?';
  const result=triageForMessages(data(RAW+'\n'+fresh),syntheticEnvelope([syntheticPrediction(fresh)]));
  assert.equal(result.stats.matched,1);assert.equal(result.stats.missing,1);assert.equal(result.suggestions[0].source_line,2);assert.equal(result.suggestions[0].channel,'whatsapp');
});

test('outbound and optionally future messages do not become inbound suggestions',()=>{
  const outbound=RAW.replace('from synthetic','to synthetic');
  const future=RAW.replace('2026-10-06','2026-10-07');
  const result=triageForMessages({...data(outbound+'\n'+future),asOf:'2026-10-06'},syntheticEnvelope([syntheticPrediction(outbound),syntheticPrediction(future)]));
  assert.equal(result.stats.matched,0);assert.equal(result.stats.rejected,1);assert.equal(result.stats.future,1);assert.equal(result.stats.inbound_messages,0);
});

test('invalid current files fail closed without throwing or exposing unknown fields',()=>{
  const result=triageForMessages(data('invalid message text'),syntheticEnvelope([syntheticPrediction()]));
  assert.equal(result.stats.matched,0);assert.ok(result.error);
  const p=syntheticPrediction();p.response.unexpected_private_field='SYNTHETIC DO NOT PASS THROUGH';p.result.extra='SYNTHETIC EXTRA';
  const valid=triageForMessages(data(RAW),syntheticEnvelope([p]));
  assert.equal(valid.stats.matched,1);assert.equal(JSON.stringify(valid).includes('SYNTHETIC DO NOT PASS THROUGH'),false);assert.equal(JSON.stringify(valid).includes('SYNTHETIC EXTRA'),false);
});
