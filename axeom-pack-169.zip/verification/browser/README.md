# Browser verification

Real Chromium was run on November 7, 2026 against the local HTTP preview at `http://127.0.0.1:8765/`, using a dedicated temporary browser profile and a 375 × 812 mobile viewport. All **35 checks passed**, with no uncaught JavaScript errors. This is local browser verification, not verification of a published anonymous link or a physical phone.

The original pack rendered 30 clients, $11,050 verified overdue, $2,040 completed unbilled work, 44 missed instructions, and 23 genuine items without a valid reply. The first screen clearly identifies the Price Insurance Group follow-up. Money, Requests, Clients, Opportunities, and Files navigation all worked without horizontal page overflow.

Six newly generated files, absent from the supplied pack, created one linked client with a lead, booking, invoice, partial bank payment, video, and revision message. The app recalculated the balance to add exactly $1,000 overdue, added one missing instruction and one unanswered lead, and connected all six record kinds in the client profile. A repeated upload showed zero new or changed rows and did not double-count money.

Approving a revision handoff attached the instruction, assigned an editor, created a task, and removed the missing-instruction alert. Completing its checkbox persisted. Updating the existing payment cleared the new overdue balance without adding a duplicate receipt. A batch containing one valid lead and one malformed invoice was rejected atomically. Imports, assignments, and task decisions survived reload. The Jev section correctly disclosed zero evaluated examples and unknown accuracy.

`report.json` records every check and before/after snapshots. PNGs show the actual mobile rendering. `fixtures/` contains the generated upload files; `qa-payments.csv` ends with the later $1,500 correction used in the upsert test. The test program is `../browser_qa.py` and recreates the original $500 fixture at the beginning of each run. Its test browser is closed afterward; the app's source pack is unchanged.

Run again after starting the local preview:

```sh
python3 verification/browser_qa.py
```

Python's `websocket-client` and Chromium must be available. No browser download or extra package installation was required in this environment.
