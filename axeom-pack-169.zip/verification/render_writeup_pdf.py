#!/usr/bin/env python3
"""Print the real submission writeup to PDF with installed headless Chromium."""
import base64
import json
from pathlib import Path
import shutil
import subprocess
import tempfile
import time
import urllib.request

import markdown
from pypdf import PdfReader

from browser_qa import CDP

ROOT = Path(__file__).resolve().parents[1]


def render():
    source = (ROOT / "writeup.md").read_text()
    body = markdown.markdown(source, extensions=["extra"])
    html = """<!doctype html><html lang="en"><head><meta charset="utf-8"><title>Axeom Pack 169 — writeup</title><style>
      @page { size: A4; margin: 15mm 17mm 15mm; }
      * { box-sizing: border-box; }
      body { margin:0; color:#20332f; font:10.4pt/1.34 Arial,Helvetica,sans-serif; }
      h1 { color:#183e35; font-size:19pt; line-height:1.16; letter-spacing:-.3pt; margin:0 0 10pt; padding:0 0 11pt; border-bottom:2pt solid #acc28e; }
      h2 { color:#183e35; font-size:12.3pt; line-height:1.2; margin:14pt 0 7pt; break-after:avoid; }
      p { margin:0 0 8pt; orphans:3; widows:3; }
      strong { color:#173f35; }
      code { font:9pt/1.2 monospace; color:#3c4c47; overflow-wrap:anywhere; }
      a { color:#24584a; text-decoration:none; }
      h1 + p { color:#52605b; font-size:9.2pt; }
    </style></head><body>""" + body + "</body></html>"
    profile = tempfile.TemporaryDirectory(prefix="axeom-writeup-pdf-", dir="/tmp")
    browser = subprocess.Popen([shutil.which("chromium") or "chromium", "--headless=new", "--no-sandbox", "--disable-gpu", "--disable-dev-shm-usage", "--no-first-run", "--no-default-browser-check", "--remote-debugging-address=127.0.0.1", "--remote-debugging-port=9223", "--user-data-dir=" + profile.name, "about:blank"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    cdp = None
    try:
        tab = None
        for _ in range(100):
            try:
                tabs = json.load(urllib.request.urlopen("http://127.0.0.1:9223/json/list", timeout=2))
                tab = next(t for t in tabs if t["type"] == "page")
                break
            except (OSError, StopIteration):
                time.sleep(0.1)
        if not tab:
            raise RuntimeError("Chromium did not start")
        cdp = CDP(tab["webSocketDebuggerUrl"])
        cdp.call("Page.enable")
        cdp.call("Runtime.enable")
        tree = cdp.call("Page.getFrameTree")
        cdp.call("Page.setDocumentContent", {"frameId": tree["frameTree"]["frame"]["id"], "html": html})
        cdp.evaluate("document.fonts.ready.then(()=>true)")
        result = cdp.call("Page.printToPDF", {"printBackground": True, "preferCSSPageSize": True, "displayHeaderFooter": False})
        output = ROOT / "writeup.pdf"
        output.write_bytes(base64.b64decode(result["data"]))
        pdf = PdfReader(output)
        if len(pdf.pages) > 2:
            raise RuntimeError(f"Writeup is {len(pdf.pages)} pages; brief permits 2")
        all_text = "\n".join(p.extract_text() for p in pdf.pages)
        for marker in ("30 real clients", "$11,050", "40/40", "Week 2", "no recording or transcript is invented"):
            if marker not in all_text:
                raise RuntimeError("Printed PDF is missing expected content: " + marker)
        print(json.dumps({"file": str(output), "pages": len(pdf.pages), "bytes": output.stat().st_size, "full_text_markers_verified": True}))
    finally:
        if cdp:
            cdp.ws.close()
        browser.terminate()
        try:
            browser.wait(timeout=8)
        except subprocess.TimeoutExpired:
            browser.kill()
            browser.wait(timeout=5)
        try:
            profile.cleanup()
        except OSError:
            pass


if __name__ == "__main__":
    render()
